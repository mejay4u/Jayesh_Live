﻿using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DAL_03_01_Reports
/// </summary>
public class DAL_03_01_Reports
{
    private Database _db = EnterpriseLibraryContainer.Current.GetInstance<Database>("IndrajitConString");
    public DAL_03_01_Reports()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public DataSet CourceBind()
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "CourceBind");

        return _db.ExecuteDataSet(SelectCommand);
    }
    public DataSet AreaBind()
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "AreaBind");

        return _db.ExecuteDataSet(SelectCommand);
    }

}