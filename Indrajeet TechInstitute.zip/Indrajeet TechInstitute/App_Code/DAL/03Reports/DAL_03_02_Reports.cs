﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DAL_03_02_Reports
/// </summary>
public class DAL_03_02_Reports
{
    public DAL_03_02_Reports()
    {
        //
        // TODO: Add constructor logic here
        //
    }
}