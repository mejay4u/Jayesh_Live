﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DAL_04_01_CertificateOne
/// </summary>
public class DAL_04_01_CertificateOne
{
    public DAL_04_01_CertificateOne()
    {
        //
        // TODO: Add constructor logic here
        //
    }
}