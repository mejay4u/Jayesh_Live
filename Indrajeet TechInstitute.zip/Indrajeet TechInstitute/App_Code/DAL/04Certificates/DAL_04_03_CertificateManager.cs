﻿using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DAL_04_03_CertificateManager
/// </summary>
public class DAL_04_03_CertificateManager
{
    private Database _db = EnterpriseLibraryContainer.Current.GetInstance<Database>("IndrajitConString");


    string res = string.Empty;

    public DAL_04_03_CertificateManager()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public string UpdateCertificateStatus(BAL_04_03_CertificateManager BalObj)
    {

        string Res = string.Empty;
        try
        {
            DbCommand UpdateCommand = null;
            UpdateCommand = _db.GetStoredProcCommand("usp_01_04_CertificateManager");
            _db.AddInParameter(UpdateCommand, "@Action", DbType.String, "UpdateCertificateStatus");
            _db.AddInParameter(UpdateCommand, "@StudentId", DbType.String, BalObj.StudentId);
          
            _db.AddInParameter(UpdateCommand, "@CertificateIssue", DbType.String, BalObj.CertificateIssue);
            _db.AddInParameter(UpdateCommand, "@PresentDay", DbType.String, BalObj.PresentDay);
            _db.AddInParameter(UpdateCommand, "@Percentage", DbType.String, BalObj.Percentage);
            _db.AddInParameter(UpdateCommand, "@Remark", DbType.String, BalObj.Remark);
            _db.AddInParameter(UpdateCommand, "@CourceDuration", DbType.String, BalObj.CourceDuration);
            _db.AddOutParameter(UpdateCommand, "@Result", DbType.String, 10);


            _db.ExecuteDataSet(UpdateCommand);
            Res = _db.GetParameterValue(UpdateCommand, "@Result").ToString();

        }
        catch (Exception Ex)
        {
            ErrorLog.insertIntoErrorLog("UpdateStudentRecord", Ex.Message);


        }

            return Res;
        
    }
    public DataSet GetStudentList(BAL_04_03_CertificateManager BalObj)
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_04_CertificateManager");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "GetGridData");
        _db.AddInParameter(SelectCommand, "@To", DbType.Int32,BalObj.To );
        _db.AddInParameter(SelectCommand, "@From", DbType.Int32, BalObj.From);
        return _db.ExecuteDataSet(SelectCommand);

    }
    public DataSet StudentEditApplication(BAL_04_03_CertificateManager BalObj)
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_04_CertificateManager");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "GetEditData");
        _db.AddInParameter(SelectCommand, "@StudentId", DbType.String, BalObj.StudentId);

        return _db.ExecuteDataSet(SelectCommand);
    }
    #region Image Retrival 
    public string FetchImage(BAL_04_03_CertificateManager imgInfo)
    {

        string Image = null;

        byte[] bytes = (byte[])GetData("SELECT StudentImage FROM  StudentInfo WHERE StudentId=" + imgInfo.StudentId).Rows[0]["StudentImage"];
        string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
        imgInfo.ImageUrl = "data:image/jpg;base64," + base64String;

        Image = imgInfo.ImageUrl;

        return Image;
    }
    private DataTable GetData(string query)
    {
        DataTable dt = new DataTable();
        string constr = ConfigurationManager.ConnectionStrings["IndrajitConString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand(query))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = con;
                    sda.SelectCommand = cmd;
                    sda.Fill(dt);
                }
            }
            return dt;
        }
    }
    #endregion
    #region Bind DDLs
  
    public DataSet CourceDurationBindDDL()
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "CourceDurationBindDDL");

        return _db.ExecuteDataSet(SelectCommand);
    }

    public DataSet RemarkBindDDL()
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "RemarkBindDDL");

        return _db.ExecuteDataSet(SelectCommand);
    }
    public DataSet PresentDaysBindDDL()
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "PresentDaysBindDDL");

        return _db.ExecuteDataSet(SelectCommand);
    }

    public DataSet PercentageBindDDL()
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "PercentageBindDDL");

        return _db.ExecuteDataSet(SelectCommand);
    }
    #endregion
    public DataSet GEtDDLValues(BAL_04_03_CertificateManager BalObj)
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_04_CertificateManager");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "GetDDLValues");
        _db.AddInParameter(SelectCommand, "@StudentId", DbType.String, BalObj.StudentId);

        return _db.ExecuteDataSet(SelectCommand);
    }
}