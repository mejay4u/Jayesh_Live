﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DAL_04_02_CertificateTwo
/// </summary>
public class DAL_04_02_CertificateTwo
{
    public DAL_04_02_CertificateTwo()
    {
        //
        // TODO: Add constructor logic here
        //
    }
}