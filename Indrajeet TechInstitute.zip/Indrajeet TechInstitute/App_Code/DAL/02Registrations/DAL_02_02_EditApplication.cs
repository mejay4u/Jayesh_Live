﻿using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DAL_02_02_EditApplication
/// </summary>
public class DAL_02_02_EditApplication
{
    private Database _db = EnterpriseLibraryContainer.Current.GetInstance<Database>("IndrajitConString");
    string res = string.Empty;

    public DAL_02_02_EditApplication()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    #region Bind DDLs
    public DataSet CourceBind()
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "CourceBind");

        return _db.ExecuteDataSet(SelectCommand);
    }
    public DataSet AreaBind()
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "AreaBind");

        return _db.ExecuteDataSet(SelectCommand);
    }

    public DataSet CastBind()
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "CastBind");

        return _db.ExecuteDataSet(SelectCommand);
    }

    public DataSet CategoryBind()
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "CategoryBind");

        return _db.ExecuteDataSet(SelectCommand);
    }
    public DataSet BindScheme()
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "SchemBind");

        return _db.ExecuteDataSet(SelectCommand);
    }
    #endregion


    public DataSet StudentEditApplication(BAL_02_02_EditApplication BalObj)
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_02_Students");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "GetEditData");
        _db.AddInParameter(SelectCommand, "@Id", DbType.String, BalObj.Id);

        return _db.ExecuteDataSet(SelectCommand);
    }
    // Update Record
    public string UpdateForm(BAL_02_02_EditApplication BalObj)
    {
        string Res = string.Empty;
        if (BalObj.StudentImage.Length > 0)
        {
          
            try
            {
                DbCommand UpdateCommand = null;
                UpdateCommand = _db.GetStoredProcCommand("usp_01_02_Students");
                _db.AddInParameter(UpdateCommand, "@Action", DbType.String, "UpdateFormWithImage");
                _db.AddInParameter(UpdateCommand, "@Id", DbType.String, BalObj.Id);
                _db.AddInParameter(UpdateCommand, "@CourceName", DbType.Int32, BalObj.CourceName);
                _db.AddInParameter(UpdateCommand, "@StudentName", DbType.String, BalObj.StudentName);
                _db.AddInParameter(UpdateCommand, "@FatehrName", DbType.String, BalObj.FathrName);
                _db.AddInParameter(UpdateCommand, "@Surname", DbType.String, BalObj.SurName);
                _db.AddInParameter(UpdateCommand, "@FatherFullName", DbType.String, BalObj.FatherFullName);
                _db.AddInParameter(UpdateCommand, "@Address", DbType.String, BalObj.Address);
                _db.AddInParameter(UpdateCommand, "@WardNo", DbType.String, BalObj.WardNo);
                _db.AddInParameter(UpdateCommand, "@NearMark", DbType.String, BalObj.NearMark);
                _db.AddInParameter(UpdateCommand, "@PinCode", DbType.String, BalObj.PinCode);
                _db.AddInParameter(UpdateCommand, "@MaritialStatus", DbType.String, BalObj.MaritialStatus);
                _db.AddInParameter(UpdateCommand, "@Area", DbType.Int32, BalObj.Area);
                _db.AddInParameter(UpdateCommand, "@StudentImage", DbType.Binary, BalObj.StudentImage);
                _db.AddInParameter(UpdateCommand, "@MobileNo", DbType.String, BalObj.MobileNo);
                _db.AddInParameter(UpdateCommand, "@DoB", DbType.String, BalObj.DoB);
                _db.AddInParameter(UpdateCommand, "@Age", DbType.String, Convert.ToInt32(BalObj.Age));
                _db.AddInParameter(UpdateCommand, "@Cast", DbType.Int32, BalObj.Cast);
                _db.AddInParameter(UpdateCommand, "@CategoryName", DbType.Int32, BalObj.CategoryName);
                _db.AddInParameter(UpdateCommand, "@Education", DbType.String, BalObj.Education);
                _db.AddInParameter(UpdateCommand, "@IsAlredyCourceTaken", DbType.String, BalObj.isAlredyCourceTaken);
                _db.AddInParameter(UpdateCommand, "@IfYesCourceName", DbType.String, BalObj.ifYesCourceName);
                _db.AddInParameter(UpdateCommand, "@AdharCard", DbType.String, BalObj.AdharCard);
                _db.AddInParameter(UpdateCommand, "@CourceName2", DbType.String, BalObj.CourceName2);
                _db.AddInParameter(UpdateCommand, "@SchemName", DbType.String, BalObj.SchemName);
                _db.AddInParameter(UpdateCommand, "@Documents", DbType.String, BalObj.Documents);
                _db.AddInParameter(UpdateCommand, "@StudentFullName", DbType.String, BalObj.StudentFullName);
                _db.AddOutParameter(UpdateCommand, "@Result", DbType.String, 10);


                _db.ExecuteDataSet(UpdateCommand);
                Res = _db.GetParameterValue(UpdateCommand, "@Result").ToString();
                return Res;
            }
            catch (Exception Ex)
            {
                ErrorLog.insertIntoErrorLog("UpdateStudentRecord", Ex.Message);

                return Res;
            }



            
            
        }
        else
        {
            try
            {
                DbCommand UpdateCommand = null;
                UpdateCommand = _db.GetStoredProcCommand("usp_01_02_Students");
                _db.AddInParameter(UpdateCommand, "@Action", DbType.String, "UpdateForm");

                _db.AddInParameter(UpdateCommand, "@Id", DbType.String, BalObj.Id);
                _db.AddInParameter(UpdateCommand, "@CourceName", DbType.Int32, BalObj.CourceName);
                _db.AddInParameter(UpdateCommand, "@StudentName", DbType.String, BalObj.StudentName);
                _db.AddInParameter(UpdateCommand, "@FatehrName", DbType.String, BalObj.FathrName);
                _db.AddInParameter(UpdateCommand, "@Surname", DbType.String, BalObj.SurName);
                _db.AddInParameter(UpdateCommand, "@FatherFullName", DbType.String, BalObj.FatherFullName);
                _db.AddInParameter(UpdateCommand, "@Address", DbType.String, BalObj.Address);
                _db.AddInParameter(UpdateCommand, "@WardNo", DbType.String, BalObj.WardNo);
                _db.AddInParameter(UpdateCommand, "@NearMark", DbType.String, BalObj.NearMark);
                _db.AddInParameter(UpdateCommand, "@PinCode", DbType.String, BalObj.PinCode);
                _db.AddInParameter(UpdateCommand, "@MaritialStatus", DbType.String, BalObj.MaritialStatus);
                _db.AddInParameter(UpdateCommand, "@Area", DbType.Int32, BalObj.Area);

                _db.AddInParameter(UpdateCommand, "@MobileNo", DbType.String, BalObj.MobileNo);
                _db.AddInParameter(UpdateCommand, "@DoB", DbType.String, BalObj.DoB);
                _db.AddInParameter(UpdateCommand, "@Age", DbType.String, Convert.ToInt32(BalObj.Age));
                _db.AddInParameter(UpdateCommand, "@Cast", DbType.Int32, BalObj.Cast);
                _db.AddInParameter(UpdateCommand, "@CategoryName", DbType.Int32, BalObj.CategoryName);
                _db.AddInParameter(UpdateCommand, "@Education", DbType.String, BalObj.Education);
                _db.AddInParameter(UpdateCommand, "@IsAlredyCourceTaken", DbType.String, BalObj.isAlredyCourceTaken);
                _db.AddInParameter(UpdateCommand, "@IfYesCourceName", DbType.String, BalObj.ifYesCourceName);

                _db.AddInParameter(UpdateCommand, "@AdharCard", DbType.String, BalObj.AdharCard);
                _db.AddInParameter(UpdateCommand, "@CourceName2", DbType.String, BalObj.CourceName2);
                _db.AddInParameter(UpdateCommand, "@SchemName", DbType.String, BalObj.SchemName);
                _db.AddInParameter(UpdateCommand, "@Documents", DbType.String, BalObj.Documents);
                _db.AddInParameter(UpdateCommand, "@StudentFullName", DbType.String, BalObj.StudentFullName);
                _db.AddOutParameter(UpdateCommand, "@Result", DbType.String, 10);


                _db.ExecuteDataSet(UpdateCommand);
                Res = _db.GetParameterValue(UpdateCommand, "@Result").ToString();
                return Res;
            }
            catch (Exception Ex)
            {
                ErrorLog.insertIntoErrorLog("UpdateStudentRecordWithoutIMage", Ex.Message);

                return Res;
            }



        }
   }

    public string DeleteForm(BAL_02_02_EditApplication BalObj)
    {

        try
        {
            DbCommand DeleteCommand = null;
            DeleteCommand = _db.GetStoredProcCommand("usp_01_02_Students");
            _db.AddInParameter(DeleteCommand, "@Action", DbType.String, "DeleteForm");
            _db.AddInParameter(DeleteCommand, "@Id", DbType.String, BalObj.Id);
            _db.ExecuteDataSet(DeleteCommand);

        }
        catch (Exception Ex)
        {
            res = Ex.Message;
        }


        return res;
    }

    public DataSet StudentDataAll(BAL_02_02_EditApplication BalObj)
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_02_Students");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "GetEditDataAll");
        _db.AddInParameter(SelectCommand, "@Id", DbType.String, BalObj.Id);

        return _db.ExecuteDataSet(SelectCommand);

    }

    #region Image Retrival 
    public string FetchImage(BAL_02_02_EditApplication imgInfo)
    {

        string Image = null;

        byte[] bytes = (byte[])GetData("SELECT StudentImage FROM  StudentInfo WHERE Id =" + imgInfo.Id).Rows[0]["StudentImage"];
        string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
        imgInfo.ImageUrl = "data:image/jpg;base64," + base64String;

        Image = imgInfo.ImageUrl;

        return Image;
    }
    private DataTable GetData(string query)
    {
        DataTable dt = new DataTable();
        string constr = ConfigurationManager.ConnectionStrings["IndrajitConString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand(query))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = con;
                    sda.SelectCommand = cmd;
                    sda.Fill(dt);
                }
            }
            return dt;
        }
    }

    #endregion






}