﻿using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DAL_02_03_Application
/// </summary>
public class DAL_02_03_Application
{
    private Database _db = EnterpriseLibraryContainer.Current.GetInstance<Database>("IndrajitConString");
    string constring = ConfigurationManager.ConnectionStrings["IndrajitConString"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter sda;
    DataTable dt;
    string res = string.Empty;

    public DAL_02_03_Application()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public DataSet  GetApplications()
    {


        //cmd = new SqlCommand("SELECT S.Id, S.StudentId,CONCAT(S.StudentName,	' ',S.FatehrName, ' ',S.Surname) as StudentFullName,CONVERT (varchar,S.DoB,105)as DOB,S.MobileNo,C.CourceName As CourceName,A.Area As Area FROM StudentInfo S(NOLOCK) INNER JOIN [01_01_Cource] C(NOLOCK) ON( C.Id=S.CourceName)  INNER JOIN [01_02_Area] A(NOLOCK) ON (A.Id=S.Area) ", con);
        //sda = new SqlDataAdapter(cmd);
        //dt = new DataTable("Applications");
        //sda.Fill(dt);
        //BalObj.ApplicationTable = dt;

        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_02_Students");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "GetApplications");
        return _db.ExecuteDataSet(SelectCommand);

    }
    public DataSet StudentEditApplication(BAL_02_03_Application BalObj)
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_02_Students");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "GetEditData");
        _db.AddInParameter(SelectCommand, "@StudentId", DbType.String, BalObj.StudentId);

        return _db.ExecuteDataSet(SelectCommand);
    }
    #region Image Retrival 
    public string FetchImage(BAL_02_03_Application imgInfo)
    {

        string Image = null;

        byte[] bytes = (byte[])GetData("SELECT StudentImage FROM  StudentInfo WHERE StudentId=" + imgInfo.StudentId).Rows[0]["StudentImage"];
        string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
        imgInfo.ImageUrl = "data:image/jpg;base64," + base64String;

        Image = imgInfo.ImageUrl;

        return Image;
    }
    private DataTable GetData(string query)
    {
        DataTable dt = new DataTable();
        string constr = ConfigurationManager.ConnectionStrings["IndrajitConString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand(query))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter())
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = con;
                    sda.SelectCommand = cmd;
                    sda.Fill(dt);
                }
            }
            return dt;
        }
    }
    public string DeleteForm(BAL_02_03_Application BalObj)
    {

        try
        {
            DbCommand DeleteCommand = null;
            DeleteCommand = _db.GetStoredProcCommand("usp_01_02_Students");
            _db.AddInParameter(DeleteCommand, "@Action", DbType.String, "DeleteForm");
            _db.AddInParameter(DeleteCommand, "@Id", DbType.String, BalObj.Id);
            _db.ExecuteDataSet(DeleteCommand);

        }
        catch (Exception Ex)
        {
            res = Ex.Message;
        }


        return res;
    }


    #endregion






}