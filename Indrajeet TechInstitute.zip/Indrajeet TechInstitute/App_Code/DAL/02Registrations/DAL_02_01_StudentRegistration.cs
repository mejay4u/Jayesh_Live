﻿using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DAL_02_01_StudentRegistration
/// </summary>
public class DAL_02_01_StudentRegistration
{
    ErrorLog ErrorLog = new ErrorLog();
    private Database _db = EnterpriseLibraryContainer.Current.GetInstance<Database>("IndrajitConString");
    string res = string.Empty;
    public DAL_02_01_StudentRegistration()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    #region Bind DDLs
    public DataSet CourceBind()
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "CourceBind");

        return _db.ExecuteDataSet(SelectCommand);
    }
    public DataSet AreaBind()
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "AreaBind");

        return _db.ExecuteDataSet(SelectCommand);
    }

    public DataSet CastBind()
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "CastBind");

        return _db.ExecuteDataSet(SelectCommand);
    }

    public DataSet CategoryBind()
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "CategoryBind");

        return _db.ExecuteDataSet(SelectCommand);
    }
    public DataSet BindScheme()
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "SchemBind");

        return _db.ExecuteDataSet(SelectCommand);
    }
    #endregion
    // Add New Record
    public string InsertStudent(BAL_02_01_StudentRegistration StudentObj)
    {
        string Res = string.Empty;

        try
        {
            DbCommand InsertCommand = null;
            InsertCommand = _db.GetStoredProcCommand("usp_01_02_Students");
            _db.AddInParameter(InsertCommand, "@Action", DbType.String, "AddStudent");
       //     _db.AddInParameter(InsertCommand, "@StudentId", DbType.String, StudentObj.StudentId);
            _db.AddInParameter(InsertCommand, "@CourceName", DbType.Int32, StudentObj.CourceName);
            _db.AddInParameter(InsertCommand, "@StudentName", DbType.String, StudentObj.StudentName);
            _db.AddInParameter(InsertCommand, "@FatehrName", DbType.String, StudentObj.FathrName);
            _db.AddInParameter(InsertCommand, "@Surname", DbType.String, StudentObj.SurName);
            _db.AddInParameter(InsertCommand, "@FatherFullName", DbType.String, StudentObj.FatherFullName);
            _db.AddInParameter(InsertCommand, "@Address", DbType.String, StudentObj.Address);
            _db.AddInParameter(InsertCommand, "@WardNo", DbType.String, StudentObj.WardNo);
            _db.AddInParameter(InsertCommand, "@NearMark", DbType.String, StudentObj.NearMark);
            _db.AddInParameter(InsertCommand, "@PinCode", DbType.String, StudentObj.PinCode);
            _db.AddInParameter(InsertCommand, "@MaritialStatus", DbType.String, StudentObj.MaritialStatus);
            _db.AddInParameter(InsertCommand, "@Area", DbType.Int32, StudentObj.Area);
            _db.AddInParameter(InsertCommand, "@StudentImage", DbType.Binary, StudentObj.StudentImage);
            _db.AddInParameter(InsertCommand, "@MobileNo", DbType.String, StudentObj.MobileNo);
            _db.AddInParameter(InsertCommand, "@DoB", DbType.String, StudentObj.DoB);
            _db.AddInParameter(InsertCommand, "@Age", DbType.String, Convert.ToInt32(StudentObj.Age));
            _db.AddInParameter(InsertCommand, "@Cast", DbType.Int32, StudentObj.Cast);
            _db.AddInParameter(InsertCommand, "@CategoryName", DbType.Int32, StudentObj.CategoryName);
            _db.AddInParameter(InsertCommand, "@Education", DbType.String, StudentObj.Education);
            _db.AddInParameter(InsertCommand, "@IsAlredyCourceTaken", DbType.String, StudentObj.isAlredyCourceTaken);
            _db.AddInParameter(InsertCommand, "@IfYesCourceName", DbType.String, StudentObj.ifYesCourceName);
            _db.AddInParameter(InsertCommand, "@SchemName", DbType.String, StudentObj.SchemName);
            _db.AddInParameter(InsertCommand, "@CourceName2", DbType.Int32, StudentObj.CourceName2);
            _db.AddInParameter(InsertCommand, "@AdharCard", DbType.String, StudentObj.AdharCard);
            _db.AddInParameter(InsertCommand, "@Documents", DbType.String, StudentObj.Documents);
            _db.AddInParameter(InsertCommand, "@StudentFullName", DbType.String, StudentObj.StudentFullName);
            _db.AddOutParameter(InsertCommand, "@Result", DbType.String, 10);
            
            _db.ExecuteDataSet(InsertCommand);
            Res = _db.GetParameterValue(InsertCommand, "@Result").ToString();
            return Res;
        }
        catch (Exception Ex)
        {
            ErrorLog.insertIntoErrorLog("InsertStudent", Ex.Message);
        
            return Res;
        }
    }


    public DataSet StudentEditApplication(BAL_02_01_StudentRegistration BalObj)
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_02_Students");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "GetEditData");
        _db.AddInParameter(SelectCommand, "@Id", DbType.String, BalObj.Id);

        return _db.ExecuteDataSet(SelectCommand);
    }







}