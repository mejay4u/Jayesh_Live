﻿using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DAL_01_04_Category
/// </summary>
public class DAL_01_04_Category
{
    private Database _db = EnterpriseLibraryContainer.Current.GetInstance<Database>("IndrajitConString");
    string res = string.Empty;
    public DAL_01_04_Category()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    // Add Category
    public string AddCategory(BAL_01_04_Category CatObj)
    {
       
        try
        {
            DbCommand InsertCommand = null;
            InsertCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
            _db.AddInParameter(InsertCommand, "@Action", DbType.String, "AddCategory");
            _db.AddInParameter(InsertCommand, "@CategoryName", DbType.String, CatObj.CategoryName);
            _db.ExecuteDataSet(InsertCommand);
          

        }
        catch (Exception Ex)
        {
            res = Ex.Message;
        }


        return res;
    }
    // Delete Category
    public string DeleteCategory(BAL_01_04_Category CatObj)
    {
  
        try
        {
            DbCommand DeleteCommand = null;
            DeleteCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
            _db.AddInParameter(DeleteCommand, "@Action", DbType.String, "DeleteCategory");
            _db.AddInParameter(DeleteCommand, "@Id", DbType.String, CatObj.Id);
            _db.ExecuteDataSet(DeleteCommand);
        
        }
        catch (Exception Ex)
        {
            res = Ex.Message;
        }


        return res;
    }

    // Edit Category
    public string EditCategory(BAL_01_04_Category CatObj)
    {
        try
        {
            DbCommand UpdateCommand = null;
            UpdateCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
            _db.AddInParameter(UpdateCommand, "@Action", DbType.String, "EditCategory");
            _db.AddInParameter(UpdateCommand, "@CategoryName", DbType.String, CatObj.CategoryName);
            _db.AddInParameter(UpdateCommand, "@Id", DbType.String, CatObj.Id);
            _db.ExecuteDataSet(UpdateCommand);
       
        }
        catch (Exception Ex)
        {
            res = Ex.Message;
         }


        return res;

    }
    // Bind Category Grid
    public DataSet getCategoryData()
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "GetCategory");

        return _db.ExecuteDataSet(SelectCommand);
    }
}