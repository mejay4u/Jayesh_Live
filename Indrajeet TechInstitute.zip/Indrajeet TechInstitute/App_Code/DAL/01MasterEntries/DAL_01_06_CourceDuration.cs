﻿using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DAL_01_06_CourceDuration
/// </summary>
public class DAL_01_06_CourceDuration
{
    private Database _db = EnterpriseLibraryContainer.Current.GetInstance<Database>("IndrajitConString");
    string res = string.Empty;
    public DAL_01_06_CourceDuration()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public string AddCourceDuration(BAL_01_06_CourceDuration DurationObj)
    {
      
        try
        {
            DbCommand InsertCommand = null;
            InsertCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
            _db.AddInParameter(InsertCommand, "@Action", DbType.String, "AddCourceDuration");
            _db.AddInParameter(InsertCommand, "@CourceDuration", DbType.String, DurationObj.CourceDuration);
            _db.ExecuteDataSet(InsertCommand);
       
        }
        catch (Exception Ex)
        {
            res = Ex.Message;
        }


        return res;
    }
    public string EditCourceDuration(BAL_01_06_CourceDuration DurationObj)
    {
     

        try
        {
            DbCommand UpdateCommand = null;
            UpdateCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
            _db.AddInParameter(UpdateCommand, "@Action", DbType.String, "EditCourceDuration");
            _db.AddInParameter(UpdateCommand, "@CourceDuration", DbType.String, DurationObj.CourceDuration);
            _db.AddInParameter(UpdateCommand, "@Id", DbType.String, DurationObj.Id);
            _db.ExecuteDataSet(UpdateCommand);
         

        }
        catch (Exception Ex)
        {
            res = Ex.Message;
        }


        return res;


    }
    public DataSet CourceDurationBind()
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "GetCourceDuration");

        return _db.ExecuteDataSet(SelectCommand);
    }
    public string DeleteCourceDuration(BAL_01_06_CourceDuration DurationObj)
    {
  
        try
        {
            DbCommand DeleteCommand = null;
            DeleteCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
            _db.AddInParameter(DeleteCommand, "@Action", DbType.String, "DeleteCourceDuration");
            _db.AddInParameter(DeleteCommand, "@Id", DbType.String, DurationObj.Id);
            _db.ExecuteDataSet(DeleteCommand);
       
        }
        catch (Exception Ex)
        {
            res = Ex.Message;
        }


        return res;

    }
}