﻿using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DAL_01_08_Percentage
/// </summary>
public class DAL_01_08_Percentage
{
    private Database _db = EnterpriseLibraryContainer.Current.GetInstance<Database>("IndrajitConString");
    string res = string.Empty;
    ErrorLog ErrorLog = new ErrorLog();
    public DAL_01_08_Percentage()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public string AddPercentage(BAL_01_08_Percentage BalObj)
    {

        try
        {
            DbCommand InsertCommand = null;
            InsertCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
            _db.AddInParameter(InsertCommand, "@Action", DbType.String, "AddPercentage");
            _db.AddInParameter(InsertCommand, "@Percentage", DbType.String, BalObj.Percentage);
            _db.ExecuteDataSet(InsertCommand);

        }
        catch (Exception Ex)
        {
            res = Ex.Message;
            ErrorLog.insertIntoErrorLog("AddPercentage", Ex.Message);
        }


        return res;
    }
    public string EditPercentage(BAL_01_08_Percentage BalObj)
    {


        try
        {
            DbCommand UpdateCommand = null;
            UpdateCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
            _db.AddInParameter(UpdateCommand, "@Action", DbType.String, "EditPercentage");
            _db.AddInParameter(UpdateCommand, "@Percentage", DbType.String, BalObj.Percentage);
            _db.AddInParameter(UpdateCommand, "@Id", DbType.String, BalObj.Id);
            _db.ExecuteDataSet(UpdateCommand);


        }
        catch (Exception Ex)
        {
            res = Ex.Message;
            ErrorLog.insertIntoErrorLog("EditPercentage", Ex.Message);
        }


        return res;


    }
    public DataSet PercentageBind()
    {

        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "GetPercentage");

        return _db.ExecuteDataSet(SelectCommand);
    }
    public string DeletePercentage(BAL_01_08_Percentage BalObj)
    {

        try
        {
            DbCommand DeleteCommand = null;
            DeleteCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
            _db.AddInParameter(DeleteCommand, "@Action", DbType.String, "DeletePercentage");
            _db.AddInParameter(DeleteCommand, "@Id", DbType.String, BalObj.Id);
            _db.ExecuteDataSet(DeleteCommand);

        }
        catch (Exception Ex)
        {
            res = Ex.Message;
            ErrorLog.insertIntoErrorLog("DeletePercentage", Ex.Message);
        }


        return res;

    }
}