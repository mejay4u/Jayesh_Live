﻿using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DAL_01_07_Remark
/// </summary>
public class DAL_01_07_Remark
{
    private Database _db = EnterpriseLibraryContainer.Current.GetInstance<Database>("IndrajitConString");
    string res = string.Empty;
    ErrorLog ErrorLog = new ErrorLog();

    public DAL_01_07_Remark()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public string AddRemark(BAL_01_07_Remark BalObj)
    {

        try
        {
            DbCommand InsertCommand = null;
            InsertCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
            _db.AddInParameter(InsertCommand, "@Action", DbType.String, "AddRemark");
            _db.AddInParameter(InsertCommand, "@Remark", DbType.String, BalObj.Remark);
            _db.ExecuteDataSet(InsertCommand);

        }
        catch (Exception Ex)
        {
            res = Ex.Message;
            ErrorLog.insertIntoErrorLog("AddRemark", Ex.Message);
        }


        return res;
    }
    public string EditRemark(BAL_01_07_Remark BalObj)
    {


        try
        {
            DbCommand UpdateCommand = null;
            UpdateCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
            _db.AddInParameter(UpdateCommand, "@Action", DbType.String, "EditRemark");
            _db.AddInParameter(UpdateCommand, "@Remark", DbType.String, BalObj.Remark);
            _db.AddInParameter(UpdateCommand, "@Id", DbType.String,BalObj.Id);
            _db.ExecuteDataSet(UpdateCommand);


        }
        catch (Exception Ex)
        {
            res = Ex.Message;
            ErrorLog.insertIntoErrorLog("EditRemark", Ex.Message);
        }


        return res;


    }
    public DataSet RemarkBind()
    {

        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "GetRemark");

        return _db.ExecuteDataSet(SelectCommand);
    }
    public string DeleteRemark(BAL_01_07_Remark BalObj)
    {

        try
        {
            DbCommand DeleteCommand = null;
            DeleteCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
            _db.AddInParameter(DeleteCommand, "@Action", DbType.String, "DeleteRemark");
            _db.AddInParameter(DeleteCommand, "@Id", DbType.String, BalObj.Id);
            _db.ExecuteDataSet(DeleteCommand);

        }
        catch (Exception Ex)
        {
            res = Ex.Message;
            ErrorLog.insertIntoErrorLog("DeleteRemark", Ex.Message);
        }


        return res;

    }
}