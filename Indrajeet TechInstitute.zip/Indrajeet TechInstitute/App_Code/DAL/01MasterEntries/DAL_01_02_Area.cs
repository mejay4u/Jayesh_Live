﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using System.Data;

/// <summary>
/// Summary description for DAL_01_02_Area
/// </summary>
public class DAL_01_02_Area
{
    private Database _db = EnterpriseLibraryContainer.Current.GetInstance<Database>("IndrajitConString");
    string res = string.Empty;
    public DAL_01_02_Area()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    // Add Area
    public string AddArea(BAL_01_02_Area AreaObj)
    {
        

        try
        {
            DbCommand InsertCommand = null;
            InsertCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
            _db.AddInParameter(InsertCommand, "@Action", DbType.String, "AddArea");
            _db.AddInParameter(InsertCommand, "@AreaName", DbType.String, AreaObj.AreaName);
            _db.ExecuteDataSet(InsertCommand);
         

        }
        catch (Exception Ex)
        {
            res = Ex.Message;
           
        }


        return res;

    }
    // Edit Area
    public string EditArea(BAL_01_02_Area AreaObj)
    {
        

        try
        {
            DbCommand UpdateCommand = null;
            UpdateCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
            _db.AddInParameter(UpdateCommand, "@Action", DbType.String, "EditArea");
            _db.AddInParameter(UpdateCommand, "@AreaName", DbType.String, AreaObj.AreaName);
            _db.AddInParameter(UpdateCommand, "@Id", DbType.String, AreaObj.Id);
            _db.ExecuteDataSet(UpdateCommand);
           

        }
        catch (Exception Ex)
        {
            res = Ex.Message;
        }


        return res;

    }
    // Delete Area
    public string DeleteArea(BAL_01_02_Area AreaObj)
    {
        

        try
        {
            DbCommand DeleteCommand = null;
            DeleteCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
            _db.AddInParameter(DeleteCommand, "@Action", DbType.String, "DeleteArea");
            _db.AddInParameter(DeleteCommand, "@Id", DbType.String, AreaObj.Id);
            _db.ExecuteDataSet(DeleteCommand);
          

        }
        catch (Exception Ex)
        {
            res = Ex.Message;
        }


        return res;
    }
    // Bind Area Grid
    public DataSet getAreaData()
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "GetArea");

        return _db.ExecuteDataSet(SelectCommand);
    }

}