﻿using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DAL_01_03_Cast
/// </summary>
public class DAL_01_03_Cast
{
    private Database _db = EnterpriseLibraryContainer.Current.GetInstance<Database>("IndrajitConString");
    string res = string.Empty;
    public DAL_01_03_Cast()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    //Add Cast
    public string AddCast(BAL_01_03_Cast CastObj)
    {

        try
        {
            DbCommand InsertCommand = null;
            InsertCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
            _db.AddInParameter(InsertCommand, "@Action", DbType.String, "AddCast");
            _db.AddInParameter(InsertCommand, "@CastName", DbType.String, CastObj.CastName);
            _db.ExecuteDataSet(InsertCommand);


        }
        catch (Exception Ex)
        {
            res = Ex.Message;
        }


        return res;
    }
    // Delete Cast
    public string DeleteCast(BAL_01_03_Cast CastObj)
    {
        try
        {
            DbCommand DeleteCommand = null;
            DeleteCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
            _db.AddInParameter(DeleteCommand, "@Action", DbType.String, "DeleteCast");
            _db.AddInParameter(DeleteCommand, "@Id", DbType.String, CastObj.Id);
            _db.ExecuteDataSet(DeleteCommand);

        }
        catch (Exception Ex)
        {
            res = Ex.Message;
        }


        return res;
    }

    // Edit Cast
    public string EditCast(BAL_01_03_Cast CastObj)
    {
        try
        {
            DbCommand UpdateCommand = null;
            UpdateCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
            _db.AddInParameter(UpdateCommand, "@Action", DbType.String, "EditCast");
            _db.AddInParameter(UpdateCommand, "@CastName", DbType.String, CastObj.CastName);
            _db.AddInParameter(UpdateCommand, "@Id", DbType.String, CastObj.Id);
            _db.ExecuteDataSet(UpdateCommand);

        }
        catch (Exception Ex)
        {
            res = Ex.Message;

        }


        return res;

    }

    // Bind Cast Grid
    public DataSet getCastData()
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "GetCast");

        return _db.ExecuteDataSet(SelectCommand);
    }
}