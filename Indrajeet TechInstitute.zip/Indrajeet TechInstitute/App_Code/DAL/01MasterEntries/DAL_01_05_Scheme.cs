﻿using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DAL_01_05_Scheme
/// </summary>
public class DAL_01_05_Scheme
{
    private Database _db = EnterpriseLibraryContainer.Current.GetInstance<Database>("IndrajitConString");
    string res = string.Empty;
    public DAL_01_05_Scheme()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public string AddScheme(BAL_01_05_Scheme SchemeObj)
    {
        
        try
        {
            DbCommand InsertCommand = null;
            InsertCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
            _db.AddInParameter(InsertCommand, "@Action", DbType.String, "AddScheme");
            _db.AddInParameter(InsertCommand, "@SchemeName", DbType.String, SchemeObj.SchemeName);
            _db.ExecuteDataSet(InsertCommand);
        
        }
        catch (Exception Ex)
        {
            res = Ex.Message;
        }


        return res;


    }

    public string EditScheme(BAL_01_05_Scheme SchemeObj)
    {
      
        try
        {
            DbCommand UpdateCommand = null;
            UpdateCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
            _db.AddInParameter(UpdateCommand, "@Action", DbType.String, "EditScheme");
            _db.AddInParameter(UpdateCommand, "@SchemeName", DbType.String, SchemeObj.SchemeName);
            _db.AddInParameter(UpdateCommand, "@Id", DbType.String, SchemeObj.Id);
            _db.ExecuteDataSet(UpdateCommand);
        }
        catch (Exception Ex)
        {
            res = Ex.Message;
        }


        return res ;

    }

    public string DeleteScheme(BAL_01_05_Scheme SchemeObj )
    {
      
        try
        {
            DbCommand DeleteCommand = null;
            DeleteCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
            _db.AddInParameter(DeleteCommand, "@Action", DbType.String, "DeleteScheme");
            _db.AddInParameter(DeleteCommand, "@Id", DbType.String, SchemeObj.Id);
            _db.ExecuteDataSet(DeleteCommand);
      
        }
        catch (Exception Ex)
        {
            res = Ex.Message;
        }


        return res;
    }


    public DataSet getSchemeData()
    {
        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "GetSchemeData");

        return _db.ExecuteDataSet(SelectCommand);
    }

}