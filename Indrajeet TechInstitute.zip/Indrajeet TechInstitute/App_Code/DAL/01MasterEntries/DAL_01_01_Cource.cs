﻿using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for DAL_01_01_Cource
/// </summary>
public class DAL_01_01_Cource
{
    private Database _db = EnterpriseLibraryContainer.Current.GetInstance<Database>("IndrajitConString");
    public DAL_01_01_Cource()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    //Add Cource
    public string AddCource(BAL_01_01_Cource CourceObj)
    {
        string res = string.Empty;

        try
        {
            DbCommand InsertCommand = null;
            InsertCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
            _db.AddInParameter(InsertCommand, "@Action", DbType.String, "AddCource");
            _db.AddInParameter(InsertCommand, "@CourceName", DbType.String, CourceObj.CourceName);
            _db.ExecuteDataSet(InsertCommand);


        }
        catch (Exception Ex)
        {
            res = Ex.Message;
        }
        return res;
    }

    // Delete Cource
    public string DeleteCource(BAL_01_01_Cource CourceObj)
    {
        string res = string.Empty;
        try
        {
            DbCommand DeleteCommand = null;
            DeleteCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
            _db.AddInParameter(DeleteCommand, "@Action", DbType.String, "DeleteCource");
            _db.AddInParameter(DeleteCommand, "@Id", DbType.String, CourceObj.Id);
            _db.ExecuteDataSet(DeleteCommand);


        }
        catch (Exception Ex)
        {
            res = Ex.Message;
        }
        return res;
    }

    // Edit Cource
    public string EditCource(BAL_01_01_Cource CourceObj)
    {
        string res = string.Empty;
        try
        {
            DbCommand UpdateCommand = null;
            UpdateCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
            _db.AddInParameter(UpdateCommand, "@Action", DbType.String, "EditCource");
            _db.AddInParameter(UpdateCommand, "@CourceName", DbType.String, CourceObj.CourceName);
            _db.AddInParameter(UpdateCommand, "@Id", DbType.String, CourceObj.Id);
            _db.ExecuteDataSet(UpdateCommand);

        }
        catch (Exception Ex)
        {
            res = Ex.Message;
        }


        return res;

    }
    // Bind Cource Grid
    public DataSet getCourceData()
    {

        DbCommand SelectCommand = null;
        SelectCommand = _db.GetStoredProcCommand("usp_01_01_MasterCrude");
        _db.AddInParameter(SelectCommand, "@Action", DbType.String, "GetCource");

        return _db.ExecuteDataSet(SelectCommand);
    }

}