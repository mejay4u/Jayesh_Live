﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for ErrorLog
/// </summary>
public class ErrorLog
{

    static string ConnectionString = ConfigurationManager.ConnectionStrings["IndrajitConString"].ConnectionString;

    public ErrorLog()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    internal static void insertIntoErrorLog(string FunctionName, string ErrorMessage)
    {
        using (SqlConnection con = new SqlConnection(ConnectionString))
        {
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "usp_ErrorLog";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@Action", "InsertIntoErrorLog"));
                cmd.Parameters.Add(new SqlParameter("@FunctionName", FunctionName));
                cmd.Parameters.Add(new SqlParameter("@ErrorMessage", ErrorMessage));
               
  
                cmd.ExecuteNonQuery();
            }
            catch (Exception Ex)
            {
                if (con != null)
                    con.Close();

            }
        }

    }
}