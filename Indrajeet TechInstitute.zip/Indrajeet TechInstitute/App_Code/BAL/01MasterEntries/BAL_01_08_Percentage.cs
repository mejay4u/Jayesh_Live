﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for BAL_01_08_Percentage
/// </summary>
public class BAL_01_08_Percentage
{
    public BAL_01_08_Percentage()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public string Id { get; set; }

    public string Percentage { get; set; }
}