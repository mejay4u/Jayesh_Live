﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for BAL_01_01_Cource
/// </summary>
public class BAL_01_01_Cource
{
    public BAL_01_01_Cource()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public string Id { get; set; }

    public string CourceName { get; set; }

}