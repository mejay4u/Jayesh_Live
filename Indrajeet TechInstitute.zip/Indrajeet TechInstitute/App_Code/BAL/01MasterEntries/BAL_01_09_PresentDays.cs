﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for BAL_01_09_PresentDays
/// </summary>
public class BAL_01_09_PresentDays
{
    public BAL_01_09_PresentDays()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public string Id { get; set; }

    public string PresentDay { get; set; }
}