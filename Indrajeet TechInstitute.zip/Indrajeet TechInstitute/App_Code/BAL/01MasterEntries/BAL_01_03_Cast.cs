﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for BAL_01_03_Cast
/// </summary>
public class BAL_01_03_Cast
{
    public BAL_01_03_Cast()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public string Id { get; set; }
    public string CastName { get; set; }
}