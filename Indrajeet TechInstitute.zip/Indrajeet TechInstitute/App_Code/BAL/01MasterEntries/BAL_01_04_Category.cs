﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for BAL_01_04_Category
/// </summary>
public class BAL_01_04_Category
{
    public BAL_01_04_Category()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public string Id { get; set; }
    public string CategoryName { get; set; }
}