﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for BAL_01_05_Scheme
/// </summary>
public class BAL_01_05_Scheme
{
    public BAL_01_05_Scheme()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public string Id { get; set; }
    public string SchemeName { get; set; }
}