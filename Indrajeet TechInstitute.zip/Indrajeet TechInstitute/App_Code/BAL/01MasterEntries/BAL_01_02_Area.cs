﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for BAL_01_02_Area
/// </summary>
public class BAL_01_02_Area
{
    public BAL_01_02_Area()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public string Id { get; set; }
    public string AreaName { get; set; }
}