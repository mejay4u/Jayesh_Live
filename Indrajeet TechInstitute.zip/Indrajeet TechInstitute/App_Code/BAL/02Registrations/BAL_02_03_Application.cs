﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for BAL_02_03_Application
/// </summary>
public class BAL_02_03_Application
{
    public BAL_02_03_Application()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public string Id { get; set; }

    public string StudentId { get; set; }

    public int CourceName { get; set; }

    public int CourceName2 { get; set; }

    public int SchemName { get; set; }

    public string StudentName { get; set; }

    public string FathrName { get; set; }

    public string SurName { get; set; }

    public string FatherFullName { get; set; }

    public string Address { get; set; }

    public string NearMark { get; set; }

    public int PinCode { get; set; }

    public string MaritialStatus { get; set; }

    public int Area { get; set; }

    public string WardNo { get; set; }

    public byte[] StudentImage { get; set; }

    public string MobileNo { get; set; }

    public string DoB { get; set; }

    public string Age { get; set; }

    public int Cast { get; set; }

    public int CategoryName { get; set; }

    public string Education { get; set; }

    public string isAlredyCourceTaken { get; set; }

    public string ifYesCourceName { get; set; }

    public string AdharCard { get; set; }

    public string Documents { get; set; }

    public string StudentFullName { get; set; }


    public string ImageUrl { get; set; }

    public DataTable ApplicationTable
    {
        get;
        set;

    }
}