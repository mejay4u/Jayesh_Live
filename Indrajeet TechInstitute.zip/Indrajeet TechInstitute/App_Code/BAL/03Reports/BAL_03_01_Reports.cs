﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for BAL_03_01_Reports
/// </summary>
public class BAL_03_01_Reports
{
    public BAL_03_01_Reports()
    {
        //
        // TODO: Add constructor logic here
        //
    }


}