﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for BAL_03_02_Reports2
/// </summary>
public class BAL_03_02_Reports2
{
    public BAL_03_02_Reports2()
    {
        //
        // TODO: Add constructor logic here
        //
    }
}