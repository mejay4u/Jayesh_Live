﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for BAL_04_02_CertificateTwo
/// </summary>
public class BAL_04_02_CertificateTwo
{
    public BAL_04_02_CertificateTwo()
    {
        //
        // TODO: Add constructor logic here
        //
    }
}