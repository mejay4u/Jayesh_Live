﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for BAL_04_01_CertificateOne
/// </summary>
public class BAL_04_01_CertificateOne
{
    public BAL_04_01_CertificateOne()
    {
        //
        // TODO: Add constructor logic here
        //
    }
}