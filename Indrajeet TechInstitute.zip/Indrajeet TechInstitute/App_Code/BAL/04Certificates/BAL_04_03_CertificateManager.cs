﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for BAL_04_03_CertificateManager
/// </summary>
public class BAL_04_03_CertificateManager
{
    public BAL_04_03_CertificateManager()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public int To { get; set; }
    public int From { get; set; }
    public string Id { get; set; }

    public string StudentId { get; set; }

    public int CourceName { get; set; }

    public int CourceName2 { get; set; }

    public int SchemName { get; set; }

    public string StudentName { get; set; }

    public string FathrName { get; set; }

    public string SurName { get; set; }

    public string FatherFullName { get; set; }

    public string Address { get; set; }

    public string NearMark { get; set; }

    public int PinCode { get; set; }

    public string MaritialStatus { get; set; }

    public int Area { get; set; }

    public string WardNo { get; set; }

    public byte[] StudentImage { get; set; }

    public string MobileNo { get; set; }

    public string DoB { get; set; }

    public string Age { get; set; }

    public int Cast { get; set; }

    public int CategoryName { get; set; }

    public string Education { get; set; }

    public string isAlredyCourceTaken { get; set; }

    public string ifYesCourceName { get; set; }

    public string AdharCard { get; set; }

    public string Documents { get; set; }

    public string StudentFullName { get; set; }
    public string CertificateIssue { get; set; }
    public string CourceDuration { get; set; }
    public string PresentDay { get; set; }
    public string Percentage{ get; set; }
    public string Remark { get; set; }


    public string ImageUrl { get; set; }

}