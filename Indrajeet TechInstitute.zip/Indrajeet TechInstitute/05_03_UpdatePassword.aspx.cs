﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class Pages_05_Admin_05_03_UpdatePassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnUpdatePassword_Click(object sender, EventArgs e)
    {
        MembershipUser u = Membership.GetUser(User.Identity.Name);

        try
        {
            if (u.ChangePassword(txtOldPassword.Text, txtNewPassword.Text))
            {
                string heading = "Success";
                string Image = "<img src='" + Page.ResolveUrl("~/images/Success.png") + "' alt='' />";
                string message = "Password updated successfully.";

                //AppConstants.ErrorPopUp(heading.ToString(), Image.ToString().Trim(), message.ToString().Trim(), this.Master);

            }

        }
        catch (Exception ex)
        {
            string heading = "Error";
            string Image = "<img src='" + Page.ResolveUrl("~/images/Fail.png") + "' alt='' />";
            string message = "Sorry request fail.Please contact your admin";
          //  AppConstants.ErrorPopUp(heading.ToString(), Image.ToString().Trim(), message.ToString().Trim(), this.Master);
           // AppConstants.InsertErrorLog(ex.Message, ex.StackTrace, "PendingChangeRequests:ShowPendingChangeRequestsResponsive()");

           // AppConstants.InsertErrorLog(ex.Message, ex.StackTrace, "PendingChangeRequests:ShowPendingChangeRequestsResponsive()");
          //  AppConstants.ErrorPopUp(heading.ToString(), Image.ToString().Trim(), message.ToString().Trim(), this.Master);
            //AppConstants.InsertErrorLog(ex.Message, ex.StackTrace, "PendingChangeRequests:ShowPendingChangeRequestsResponsive()");

        }

    }

}