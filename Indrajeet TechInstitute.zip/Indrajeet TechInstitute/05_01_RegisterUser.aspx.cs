﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class Pages_05_Admin_05_01_RegisterUser : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnCreateUser_Click(object sender, EventArgs e)
    {
        try
        {
            MembershipCreateStatus p = MembershipCreateStatus.Success;
            Membership.CreateUser(txtUserName.Text, txtPassword.Text, txtEmail.Text, txtSecurityQuestion.Text, txtSecurityAnswer.Text, true, out p);
            string heading = "Success";
            string Image = "<img src='" + Page.ResolveUrl("~/images/Success.png") + "' alt='' />";
            string message = "User " + txtUserName.Text + " created successfully.";

            Response.Redirect("Login.aspx");

            // AppConstants.ErrorPopUp(heading.ToString(), Image.ToString().Trim(), message.ToString().Trim(), this.Master);
            //           AppConstants.ErrorPopUp(heading.ToString(), Image.ToString().Trim(), message.ToString().Trim(), this.Master);
        }
        catch (Exception ex)
        {

            // AppConstants.InsertErrorLog(ex.Message, ex.StackTrace, "PendingChangeRequests:ShowPendingChangeRequestsResponsive()");
            //AppConstants.InsertErrorLog(ex.Message, ex.StackTrace, "PendingChangeRequests:ShowPendingChangeRequestsResponsive()");
            //  AppConstants.InsertErrorLog(ex.Message, ex.StackTrace, "PendingChangeRequests:ShowPendingChangeRequestsResponsive()");
        }
    }
}