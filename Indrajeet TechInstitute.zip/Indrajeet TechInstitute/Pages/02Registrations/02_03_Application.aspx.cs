﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;

using System.Data.SqlClient;
using System.Configuration;
using System.Web.Services;

public partial class Pages_02Registrations_Applications : System.Web.UI.Page
{
    DAL_02_03_Application DalObj = new DAL_02_03_Application();
    BAL_02_03_Application BalObj = new BAL_02_03_Application();
    private static int PageSize = 5;
    public enum MessageType { Success, Error, Info, Warning };
    protected void ShowMessage(string Message, MessageType type)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), System.Guid.NewGuid().ToString(), "ShowMessage('" + Message + "','" + type + "');", true);
    }

    string Id = string.Empty;
    DataSet Ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Update"] != null)
        {
            ShowMessage("विध्यार्थ्याचा अर्ज यशस्वीरीत्या संपादित झाला.", MessageType.Success);
            Session["Update"] = null;
        }

        if (Session["Res"] != null)
        {
            ShowMessage("अर्ज यशस्वीरीत्या जमा झाला.", MessageType.Success);
            Session["Res"] = null;
        }

        if (!IsPostBack)
        {
            BindGrid();

        }
    }

    private void BindGrid()

    {

        using (DataSet ds = DalObj.GetApplications())
        {
            ds.Tables[0].TableName = "Table";
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvApplications.DataSource = ds.Tables[0];
                gvApplications.DataBind();
            }
        }



    }
    protected void gvApplications_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int index = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName.Equals("editrecord"))
        {
            GridViewRow gvrow = gvApplications.Rows[index];
            Session["Id"] = gvApplications.DataKeys[gvrow.RowIndex].Value;
            Response.Redirect("02_02_EditApplication.aspx");


        }


        else if (e.CommandName.Equals("deleterecord"))
        {
            GridViewRow gvrow = gvApplications.Rows[index];
            string Source = null;
            Session["Id"] = gvApplications.DataKeys[gvrow.RowIndex].Value;
            Source = HttpUtility.HtmlDecode(gvrow.Cells[2].Text).Trim();
            lblDeleteBOld.Text = Source + "!<br>";
            lblDeleteMsg.Text = " आपण खरोखर हटवू इच्छिता का ? ";



            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(@"<script type='text/javascript'>");
            sb.Append("$('#modal-delete').modal('show');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "DeleteModalScript", sb.ToString(), false);


        }

        else if (e.CommandName.Equals("ViewForm"))
        {

            GridViewRow gvrow = gvApplications.Rows[index];



            Id = HttpUtility.HtmlDecode(gvrow.Cells[1].Text).Trim();

            BalObj.StudentId = Id;
            Ds = DalObj.StudentEditApplication(BalObj);
            if (Ds.Tables[0].Rows.Count > 0)
            {


                BalObj.StudentId = Id;
                string Image = DalObj.FetchImage(BalObj);
                ImageShowView.ImageUrl = Image;



                lblShowCource.Text = Ds.Tables[0].Rows[0]["CourceName"].ToString();
                lblShowArea.Text = Ds.Tables[0].Rows[0]["Area"].ToString();
                lblShowCast.Text = Ds.Tables[0].Rows[0]["Cast"].ToString();
                lblShowCategory.Text = Ds.Tables[0].Rows[0]["CategoryName"].ToString();

                lblShowAddress.Text = Ds.Tables[0].Rows[0]["Address"].ToString();
                lblShowAge.Text = Ds.Tables[0].Rows[0]["Age"].ToString();
                lblShowDob.Text = Ds.Tables[0].Rows[0]["DoB"].ToString();

                lblShowEducation.Text = Ds.Tables[0].Rows[0]["Education"].ToString();
                lblShowFatherFullName.Text = Ds.Tables[0].Rows[0]["FatherFullName"].ToString();
                lblShowFirstName.Text = Ds.Tables[0].Rows[0]["StudentName"].ToString();
                lblShowMiddlName.Text = Ds.Tables[0].Rows[0]["FatehrName"].ToString();
                lblShowNearMark.Text = Ds.Tables[0].Rows[0]["NearMark"].ToString();
                lblShowPhoneNo.Text = Ds.Tables[0].Rows[0]["MobileNo"].ToString();
                lblShowPinCode.Text = Ds.Tables[0].Rows[0]["PinCode"].ToString();
                lblShowSurName.Text = Ds.Tables[0].Rows[0]["Surname"].ToString().Trim();
                lblShowWardNo.Text = Ds.Tables[0].Rows[0]["WardNo"].ToString().Trim();
                lblShowCource2.Text = Ds.Tables[0].Rows[0]["CourceName2"].ToString().Trim();
                lblShowAdharCard.Text = Ds.Tables[0].Rows[0]["AdharCard"].ToString().Trim();
                lblShowScheme.Text = Ds.Tables[0].Rows[0]["Scheme"].ToString().Trim();
                lblShowIfalredy.Text = Ds.Tables[0].Rows[0]["IfYesCourceName"].ToString().Trim();
                string IsAlredyCourceTaken = Ds.Tables[0].Rows[0]["IsAlredyCourceTaken"].ToString().Trim();

                if (IsAlredyCourceTaken == "True")
                {
                    lblYesNo.Text = "होय";
                }
                else
                {
                    lblYesNo.Text = "नाही";

                }
                lblTitleName.Text = lblShowFirstName.Text + " " + lblShowMiddlName.Text + " " + lblShowSurName.Text;

            }

            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(@"<script type='text/javascript'>");
            sb.Append("$('#modal-details').modal('show');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "DeleteModalScript", sb.ToString(), false);
            Id = null;


        }

    }


    protected void btnDelete_Click(object sender, EventArgs e)
    {

        try
        {
            BalObj.Id = Session["Id"].ToString();

            DalObj.DeleteForm(BalObj);
            BindGrid();
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append(@"<script type='text/javascript'>");

            sb.Append("$('#modal-delete').modal('hide');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "DeleteModalScript", sb.ToString(), false);
            ShowMessage("अर्ज यशस्वीरित्या काढला .", MessageType.Info);
        }
        catch (Exception Ex)
        {
            string Message = Ex.Message;
            ShowMessage(Message, MessageType.Error);
        }

    }


    protected void gvApplications_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvApplications.PageIndex = e.NewPageIndex;
        BindGrid();
    }






}