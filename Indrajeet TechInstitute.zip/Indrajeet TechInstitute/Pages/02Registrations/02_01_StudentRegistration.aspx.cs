﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI.HtmlControls;
using System.Globalization;
using System.Threading;
using System.Web.Services;
using System.Web.Script.Services;

public partial class Pages_02Registrations_01_01_StudentRegistration : System.Web.UI.Page
{
    BAL_02_01_StudentRegistration BalObj = new BAL_02_01_StudentRegistration();
    DAL_02_01_StudentRegistration DalObj = new DAL_02_01_StudentRegistration();
    public enum MessageType { Success, Error, Info, Warning };
    DataSet Ds = new DataSet();
    
    protected void ShowMessage(string Message, MessageType type)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), System.Guid.NewGuid().ToString(), "ShowMessage('" + Message + "','" + type + "');", true);
    }

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
           

            BindDDL();


        }

    }


    
    public void BindDDL()
    {
        Ds = DalObj.CourceBind();
        ddlCourceName.DataSource = Ds.Tables[0];
        ddlCourceName.DataTextField = "CourceName";
        ddlCourceName.DataValueField = "Id";
        ddlCourceName.DataBind();

        Ds = DalObj.BindScheme();
        ddlScheme.DataSource = Ds.Tables[0];
        ddlScheme.DataTextField = "Scheme";
        ddlScheme.DataValueField = "Id";
        ddlScheme.DataBind();

        Ds = DalObj.CourceBind();
        ddlCource2.DataSource = Ds.Tables[0];
        ddlCource2.DataTextField = "CourceName";
        ddlCource2.DataValueField = "Id";
        ddlCource2.DataBind();

        Ds = DalObj.AreaBind();
        ddlArea.DataSource = Ds.Tables[0];
        ddlArea.DataTextField = "Area";
        ddlArea.DataValueField = "Id";
        ddlArea.DataBind();

        Ds = DalObj.CastBind();
        ddlCast.DataSource = Ds.Tables[0];
        ddlCast.DataTextField = "CastName";
        ddlCast.DataValueField = "Id";
        ddlCast.DataBind();

        Ds = DalObj.CategoryBind();
        ddlCategory.DataSource = Ds.Tables[0];
        ddlCategory.DataTextField = "Category";
        ddlCategory.DataValueField = "Id";
        ddlCategory.DataBind();



    }
    
   

    protected void btnSubmit_Click(object sender, EventArgs e)
    {


       
        try
        {


            int imageln = fuStudentPic.PostedFile.ContentLength;
            byte[] picByte = new byte[imageln];
            fuStudentPic.PostedFile.InputStream.Read(picByte, 0, imageln);
     
            BalObj.CourceName2 = Convert.ToInt32(ddlCource2.SelectedValue);
            BalObj.CourceName = Convert.ToInt32(ddlCourceName.SelectedValue);
            BalObj.SchemName = Convert.ToInt32(ddlScheme.SelectedValue);
            BalObj.StudentName = txtFirstName.Text.Trim();
            BalObj.FathrName = txtMiddlename.Text.Trim();
            BalObj.SurName = txtSurname.Text.Trim();
            BalObj.FatherFullName = txtFathersName.Text.Trim();
            BalObj.Address = txtAddress.Text.Trim();
            BalObj.NearMark = txtNearMark.Text.Trim();
            BalObj.PinCode = txtPinCode.Text.Trim();
            BalObj.MaritialStatus = ddlMaritiulStatus.SelectedValue.ToString().Trim();
            BalObj.Area = Convert.ToInt32(ddlArea.SelectedValue);
            BalObj.WardNo = txtWardNo.Text.Trim();
            BalObj.StudentImage = picByte;
            BalObj.MobileNo = txtPhoneNumber.Text.Trim();
          
         
            
            BalObj.DoB =  txtDob.Text.Trim();
            

            
            BalObj.Age = txtAge.Text.Trim();
            BalObj.Cast = Convert.ToInt32(ddlCast.SelectedValue);
            BalObj.CategoryName = Convert.ToInt32(ddlCategory.SelectedValue);
            BalObj.Education = txtEducation.Text.Trim();
            BalObj.isAlredyCourceTaken = rdoYesNo.SelectedValue;
            BalObj.ifYesCourceName = txtIfAlredyCourceTaken.Text.Trim();
            BalObj.AdharCard = txtAdharNo.Text.Trim();
            BalObj.StudentFullName = txtFirstName.Text.Trim() + txtMiddlename.Text.Trim() + txtSurname.Text.Trim();
            StringBuilder sb = new StringBuilder();

            foreach (ListItem doc in chkDocumentList.Items)
            {

                if (doc.Selected)
                {
                    sb.Append(doc.Value.ToString().Trim());
                    sb.Append(",");
                    sb.AppendFormat("");
                }
            }
            BalObj.Documents = sb.ToString().Trim();

            string Res = DalObj.InsertStudent(BalObj);
            if (Res == "1")
            {
                Session["Res"] = Res;
                Response.Redirect("../02Registrations/02_03_Application.aspx");
                // ShowMessage("विध्यार्थी: " + txtFirstName.Text + "" + txtSurname.Text + " चा अर्ज यशस्वीरित्या समाविष्ट झाला .", MessageType.Success);
                resetall();
            }
            if (Res == "2")
            {

                ShowMessage("विध्यार्थी: " + txtFirstName.Text + "" + txtSurname.Text + " चा अर्ज याआधी समाविष्ट झाला आहे .", MessageType.Warning);
             
            }
            else
            {
                ShowMessage(Res + "Student registration failed", MessageType.Error);
            }




        }
        catch (Exception ex)
        {
            string Message = ex.Message;
            ShowMessage("Registration Failed, Please contact yoyr Admin", MessageType.Error);
        }


    }


    public void resetall()
    {
        ddlArea.SelectedValue = "0";
        ddlCast.SelectedValue = "0";
        ddlCategory.SelectedValue = "0";
        ddlCourceName.SelectedValue = "0";
        ddlMaritiulStatus.SelectedValue = "0";
        ddlCource2.SelectedValue ="0";
        ddlScheme.SelectedValue = "0";
        txtAddress.Text = null;
        txtAge.Text = null;
        txtDob.Text = null;
        txtEducation.Text = null;
        txtFathersName.Text = null;
        txtFirstName.Text = null;
        txtIfAlredyCourceTaken.Text = null;
        txtMiddlename.Text = null;
        txtNearMark.Text = null;
        txtPhoneNumber.Text = null;
        txtPinCode.Text = null;
        txtSurname.Text = null;
        txtWardNo.Text = null;
        txtAdharNo.Text = null;
        txtPhoneNumber.Text = null;
        chkDocumentList.ClearSelection();
      

    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("../02Registrations/02_03_Application.aspx");
    }

    protected void btnReset_Click(object sender, EventArgs e)
    {
        resetall();
    }



    protected void rdoYesNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (rdoYesNo.SelectedValue == "1")
        {
            txtIfAlredyCourceTaken.ReadOnly = false;

        }
        else
        {

            txtIfAlredyCourceTaken.ReadOnly = true;
        }
    }

    // WebMethod for Cheking Student Exist or Not
    [WebMethod]
    [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
    public static string ChekStudentName(string StudentFullName)
    {
        string returnValue = string.Empty;
        try
        {
            string consString = ConfigurationManager
                    .ConnectionStrings["IndrajitConString"].ConnectionString;
            System.Data.SqlClient.SqlConnection conn = new SqlConnection(consString);
            SqlCommand cmd = new SqlCommand("usp_01_03_ChekStudent", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@StudentFullName", StudentFullName.Trim());
            conn.Open();
            returnValue = cmd.ExecuteScalar().ToString();
            conn.Close();
           
        }
        catch
        {
            returnValue = "error";
        }
        return returnValue;
       
    }

}