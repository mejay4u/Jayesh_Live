﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Pages_02Registrations_02_02_EditApplication : System.Web.UI.Page
{
    BAL_02_02_EditApplication BalObj = new BAL_02_02_EditApplication();
    DAL_02_02_EditApplication DalObjEdit = new DAL_02_02_EditApplication();
    string rs = string.Empty;
    public enum MessageType { Success, Error, Info, Warning };
    DataSet Ds = new DataSet();

    string Id = "";
    protected void ShowMessage(string Message, MessageType type)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), System.Guid.NewGuid().ToString(), "ShowMessage('" + Message + "','" + type + "');", true);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {


            BindDDL();
            EditRecord();

        }

    }
    protected void rdoYesNo_SelectedIndexChanged(object sender, EventArgs e)
    {

        if (rdoYesNo.SelectedValue == "True")
        {
            txtIfAlredyCourceTaken.ReadOnly = false;

        }
        else
        {

            txtIfAlredyCourceTaken.ReadOnly = true;
        }

    }
    public void BindDDL()
    {
        Ds = DalObjEdit.CourceBind();
        ddlCourceName.DataSource = Ds.Tables[0];
        ddlCourceName.DataTextField = "CourceName";
        ddlCourceName.DataValueField = "Id";
        ddlCourceName.DataBind();

        Ds = DalObjEdit.BindScheme();
        ddlScheme.DataSource = Ds.Tables[0];
        ddlScheme.DataTextField = "Scheme";
        ddlScheme.DataValueField = "Id";
        ddlScheme.DataBind();

        Ds = DalObjEdit.CourceBind();
        ddlCource2.DataSource = Ds.Tables[0];
        ddlCource2.DataTextField = "CourceName";
        ddlCource2.DataValueField = "Id";
        ddlCource2.DataBind();

        Ds = DalObjEdit.AreaBind();
        ddlArea.DataSource = Ds.Tables[0];
        ddlArea.DataTextField = "Area";
        ddlArea.DataValueField = "Id";
        ddlArea.DataBind();

        Ds = DalObjEdit.CastBind();
        ddlCast.DataSource = Ds.Tables[0];
        ddlCast.DataTextField = "CastName";
        ddlCast.DataValueField = "Id";
        ddlCast.DataBind();

        Ds = DalObjEdit.CategoryBind();
        ddlCategory.DataSource = Ds.Tables[0];
        ddlCategory.DataTextField = "Category";
        ddlCategory.DataValueField = "Id";
        ddlCategory.DataBind();


    }


    public void EditRecord()
    {
        BAL_02_02_EditApplication BalObjEdit = new BAL_02_02_EditApplication();
        if (Session["Id"] != null)
        {



            Id = Session["Id"].ToString();



            BalObjEdit.Id = Id;
            Ds = DalObjEdit.StudentDataAll(BalObjEdit);
            if (Ds.Tables[0].Rows.Count > 0)
            {


                BalObjEdit.Id = Id;
                string Image = DalObjEdit.FetchImage(BalObjEdit);
                ImageView.ImageUrl = Image;


                ddlCource2.SelectedValue = Ds.Tables[0].Rows[0]["CourceName2"].ToString();
                ddlCourceName.SelectedValue = Ds.Tables[0].Rows[0]["CourceName"].ToString();
                ddlArea.SelectedValue = Ds.Tables[0].Rows[0]["Area"].ToString();
                ddlCast.SelectedValue = Ds.Tables[0].Rows[0]["Cast"].ToString();
                ddlCategory.SelectedValue = Ds.Tables[0].Rows[0]["CategoryName"].ToString();
                ddlMaritiulStatus.SelectedValue = Ds.Tables[0].Rows[0]["MaritialStatus"].ToString();
                txtAddress.Text = Ds.Tables[0].Rows[0]["Address"].ToString();
                txtAge.Text = Ds.Tables[0].Rows[0]["Age"].ToString();
                txtDob.Text = Ds.Tables[0].Rows[0]["DoB"].ToString();
                ddlCource2.SelectedValue = Ds.Tables[0].Rows[0]["CourceName2"].ToString();
                ddlScheme.SelectedValue = Ds.Tables[0].Rows[0]["Scheme"].ToString();
                txtAdharNo.Text = Ds.Tables[0].Rows[0]["AdharCard"].ToString();
                txtEducation.Text = Ds.Tables[0].Rows[0]["Education"].ToString();
                txtFathersName.Text = Ds.Tables[0].Rows[0]["FatherFullName"].ToString();
                txtFirstName.Text = Ds.Tables[0].Rows[0]["StudentName"].ToString();
                txtMiddlename.Text = Ds.Tables[0].Rows[0]["FatehrName"].ToString();
                txtNearMark.Text = Ds.Tables[0].Rows[0]["NearMark"].ToString();
                txtPhoneNumber.Text = Ds.Tables[0].Rows[0]["MobileNo"].ToString();
                txtPinCode.Text = Ds.Tables[0].Rows[0]["PinCode"].ToString();
                txtSurname.Text = Ds.Tables[0].Rows[0]["Surname"].ToString().Trim();
                txtWardNo.Text = Ds.Tables[0].Rows[0]["WardNo"].ToString().Trim();
                rdoYesNo.SelectedValue = Ds.Tables[0].Rows[0]["IsAlredyCourceTaken"].ToString();
                txtIfAlredyCourceTaken.Text = Ds.Tables[0].Rows[0]["IfYesCourceName"].ToString().Trim();

                string doclist = string.Empty;
                doclist = Ds.Tables[0].Rows[0]["Documents"].ToString().Trim(',');



                foreach (ListItem item in chkDocumentList.Items)
                {
                    foreach (char doc in doclist)
                    {
                        if (item.Value == doc.ToString())
                        {
                            item.Selected = true;
                        }
                    }
                }



            }
        }
    }



    protected void btnSubmit_Click(object sender, EventArgs e)
    {


        try
        {
            Id = Session["Id"].ToString();
            Session["Id"] = null;

            int imageln = fuStudentPic.PostedFile.ContentLength;
            byte[] picByte = new byte[imageln];
            fuStudentPic.PostedFile.InputStream.Read(picByte, 0, imageln);
            BalObj.Id = Id;
            BalObj.CourceName = Convert.ToInt32(ddlCourceName.SelectedValue);
            BalObj.StudentName = txtFirstName.Text;
            BalObj.FathrName = txtMiddlename.Text;
            BalObj.SurName = txtSurname.Text;
            BalObj.FatherFullName = txtFathersName.Text;
            BalObj.Address = txtAddress.Text;
            BalObj.NearMark = txtNearMark.Text;
            BalObj.PinCode = txtPinCode.Text;
            BalObj.MaritialStatus = ddlMaritiulStatus.SelectedValue.ToString();
            BalObj.Area = Convert.ToInt32(ddlArea.SelectedValue);
            BalObj.WardNo = txtWardNo.Text;
            BalObj.StudentImage = picByte;
            BalObj.MobileNo = txtPhoneNumber.Text;
            BalObj.DoB = txtDob.Text;
            BalObj.Age = txtAge.Text;
            BalObj.Cast = Convert.ToInt32(ddlCast.SelectedValue);
            BalObj.CategoryName = Convert.ToInt32(ddlCategory.SelectedValue);
            BalObj.Education = txtEducation.Text;
            BalObj.isAlredyCourceTaken = rdoYesNo.SelectedValue;
            BalObj.ifYesCourceName = txtIfAlredyCourceTaken.Text;
            BalObj.AdharCard = txtAdharNo.Text;
            BalObj.CourceName2 = Convert.ToInt32(ddlCource2.SelectedValue);
            BalObj.SchemName = Convert.ToInt32(ddlScheme.SelectedValue);
            BalObj.StudentFullName = txtFirstName.Text + txtMiddlename.Text + txtSurname.Text;
            StringBuilder sb = new StringBuilder();

            foreach (ListItem doc in chkDocumentList.Items)
            {

                if (doc.Selected)
                {
                    sb.Append(doc.Value.ToString().Trim());
                    sb.Append(",");
                    sb.AppendFormat("");
                }
            }
            BalObj.Documents = sb.ToString();


            string Res = DalObjEdit.UpdateForm(BalObj);
            if (Res == "1")
            {

                Session["Update"] = Res;
                Response.Redirect("../02Registrations/02_03_Application.aspx");
                // ShowMessage("विध्यार्थी: " + txtFirstName.Text + "" + txtSurname.Text + " चा अर्ज यशस्वीरित्या समाविष्ट झाला .", MessageType.Success);
                resetall();


            }
            else
            {
                ShowMessage(Res + "Student updation failed", MessageType.Error);
            }
        }
        catch (Exception ex)
        {
            string Message = ex.Message;
            ShowMessage("Updation Failed, Please contact yoyr Admin", MessageType.Error);
        }

    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("../02Registrations/02_03_Application.aspx");
    }
    public void resetall()
    {
        ddlArea.SelectedIndex = 0;
        ddlCast.SelectedIndex = 0;
        ddlCategory.SelectedIndex = 0;
        ddlCourceName.SelectedIndex = 0;
        ddlMaritiulStatus.SelectedIndex = 0;
        ddlCource2.SelectedIndex = 0;
        ddlScheme.SelectedIndex = 0;
        txtAddress.Text = null;
        txtAge.Text = null;
        txtDob.Text = null;
        txtEducation.Text = null;
        txtFathersName.Text = null;
        txtFirstName.Text = null;
        txtIfAlredyCourceTaken.Text = null;
        txtMiddlename.Text = null;
        txtNearMark.Text = null;
        txtPhoneNumber.Text = null;
        txtPinCode.Text = null;
        txtSurname.Text = null;
        txtWardNo.Text = null;
        txtAdharNo.Text = null;
        txtPhoneNumber.Text = null;

    }

    protected void btnReset_Click(object sender, EventArgs e)
    {
        resetall();

    }
}