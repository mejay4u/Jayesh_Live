﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Pages_01MasterEntries_01_01_Cource : System.Web.UI.Page
{
    BAL_01_01_Cource BalObj = new BAL_01_01_Cource();
    DAL_01_01_Cource DalObj = new DAL_01_01_Cource();
    string Message = string.Empty;

    public enum MessageType { Success, Error, Info, Warning };
    protected void ShowMessage(string Message, MessageType type)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), System.Guid.NewGuid().ToString(), "ShowMessage('" + Message + "','" + type + "');", true);
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindGrid();
        }
    }
    //Method for Bind Grid
    private void BindGrid()

    {
        gvCources.DataSource = DalObj.getCourceData();
        gvCources.DataBind();

    }
    //Add New Course
    protected void btnAddNewCource_Click(object sender, EventArgs e)
    {


        try
        {
            BalObj.CourceName = txtNewCourceName.Text;


            DalObj.AddCource(BalObj);
            BindGrid();
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(@"<script type='text/javascript'>");
            sb.Append("$('#modal-success').modal('show');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "DeleteModalScript", sb.ToString(), false);
            ShowMessage("कोर्स यशस्वीरित्या जोडला.", MessageType.Success);
            txtNewCourceName.Text = null;

        }
        catch (Exception Ex)
        {
            Message = Ex.Message;
            ShowMessage(Message, MessageType.Error);
        }


    }
    //Grid Manipulation
    protected void gvCources_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int index = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName.Equals("editrecord"))
        {

            GridViewRow gvrow = gvCources.Rows[index];
            hfId.Value = HttpUtility.HtmlDecode(gvrow.Cells[0].Text);

            txtCourceEdit.Text = HttpUtility.HtmlDecode(gvrow.Cells[1].Text);
            BindGrid();
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(@"<script type='text/javascript'>");
            sb.Append("$('#modal-edit').modal('show');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "EditModalScript", sb.ToString(), false);
        }


        else if (e.CommandName.Equals("deleterecord"))
        {
            GridViewRow gvrow = gvCources.Rows[index];
            string Source = null;
            Source = HttpUtility.HtmlDecode(gvrow.Cells[1].Text).Trim();
            lblDeleteBOld.Text = Source + "!<br>";
            lblDeleteMsg.Text = " आपण खरोखर हटवू इच्छिता का ? ";
            hfId.Value = gvCources.DataKeys[index].Values[0].ToString();

            BindGrid();
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(@"<script type='text/javascript'>");
            sb.Append("$('#modal-delete').modal('show');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "DeleteModalScript", sb.ToString(), false);


        }

    }
    //Edit Cource
    protected void btnEditCource_Click(object sender, EventArgs e)
    {

        try
        {

            BalObj.Id = hfId.Value;
            BalObj.CourceName = txtCourceEdit.Text;

            DalObj.EditCource(BalObj);
            BindGrid();
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(@"<script type='text/javascript'>");

            sb.Append("$('#modal-edit').modal('hide');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "DeleteModalScript", sb.ToString(), false);
            ShowMessage("कोर्स यशस्वीरित्या संपादित झाला.", MessageType.Success);

        }
        catch (Exception Ex)
        {

            Message = Ex.Message;
            ShowMessage(Message, MessageType.Error);
        }


    }
    //Delete Cource
    protected void btnDelete_Click(object sender, EventArgs e)
    {


        try
        {
            BalObj.Id = hfId.Value;

            DalObj.DeleteCource(BalObj);
            BindGrid();

            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append(@"<script type='text/javascript'>");

            sb.Append("$('#modal-delete').modal('hide');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "DeleteModalScript", sb.ToString(), false);
            ShowMessage("कोर्स यशस्वीरित्या काढला .", MessageType.Info);
        }
        catch (Exception Ex)
        {
            Message = Ex.Message;
            ShowMessage(Message, MessageType.Error);
        }

    }

    protected void gvCources_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvCources.PageIndex = e.NewPageIndex;
        BindGrid();

    }
}