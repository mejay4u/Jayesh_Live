﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Pages_01MasterEntries_01_09_PresentDays : System.Web.UI.Page
{
    BAL_01_09_PresentDays BalObj = new BAL_01_09_PresentDays();
    DAL_01_09_PresentDays DalObj = new DAL_01_09_PresentDays();
    string Message = string.Empty;
    public enum MessageType { Success, Error, Info, Warning };
    protected void ShowMessage(string Message, MessageType type)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), System.Guid.NewGuid().ToString(), "ShowMessage('" + Message + "','" + type + "');", true);
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindGrid();
        }
    }
    private void BindGrid()

    {

        gvPresentDays.DataSource = DalObj.PresentDaysBind();
        gvPresentDays.DataBind();


    }


    protected void gvPresentDays_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int index = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName.Equals("editrecord"))
        {

            GridViewRow gvrow = gvPresentDays.Rows[index];
            hfId.Value = HttpUtility.HtmlDecode(gvrow.Cells[0].Text);

            txtPresentDaysEdit.Text = HttpUtility.HtmlDecode(gvrow.Cells[1].Text);
            BindGrid();
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(@"<script type='text/javascript'>");
            sb.Append("$('#modal-edit').modal('show');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "EditModalScript", sb.ToString(), false);
        }


        else if (e.CommandName.Equals("deleterecord"))
        {
            GridViewRow gvrow = gvPresentDays.Rows[index];
            string Source = null;
            Source = HttpUtility.HtmlDecode(gvrow.Cells[1].Text).Trim();
            lblDeleteBOld.Text = Source + "!<br>";
            lblDeleteMsg.Text = " आपण खरोखर हटवू इच्छिता का ? ";
            hfId.Value = gvPresentDays.DataKeys[index].Values[0].ToString();

            BindGrid();
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(@"<script type='text/javascript'>");
            sb.Append("$('#modal-delete').modal('show');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "DeleteModalScript", sb.ToString(), false);


        }

    }

    protected void btnAddNewPresentDays_Click(object sender, EventArgs e)
    {

        try
        {
            BalObj.PresentDay = txtNewPresentDays.Text.Trim();


            DalObj.AddPresentDays(BalObj);
            BindGrid();
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(@"<script type='text/javascript'>");
            sb.Append("$('#modal-success').modal('show');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "DeleteModalScript", sb.ToString(), false);
            ShowMessage("	उपस्तिथी दिवस यशस्वीरित्या जोडले.", MessageType.Success);
            txtNewPresentDays.Text = null;

        }
        catch (Exception Ex)
        {
            Message = Ex.Message;
            ShowMessage(Message, MessageType.Error);

        }



    }

    protected void btnPresentDaysEdit_Click(object sender, EventArgs e)
    {
        try
        {

            BalObj.Id = hfId.Value;
            BalObj.PresentDay = txtPresentDaysEdit.Text.Trim();

            DalObj.EditPresentDays(BalObj);
            BindGrid();
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(@"<script type='text/javascript'>");

            sb.Append("$('#modal-edit').modal('hide');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "DeleteModalScript", sb.ToString(), false);
            ShowMessage("	उपस्तिथी दिवस यशस्वीरित्या संपादित झाले.", MessageType.Success);

        }
        catch (Exception Ex)
        {
            Message = Ex.Message;
            ShowMessage(Message, MessageType.Error);
        }
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            BalObj.Id = hfId.Value;
            DalObj.DeletePresentDays(BalObj);
            BindGrid();

            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append(@"<script type='text/javascript'>");

            sb.Append("$('#modal-delete').modal('hide');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "DeleteModalScript", sb.ToString(), false);
            ShowMessage("	उपस्तिथी दिवस यशस्वीरित्या काढले .", MessageType.Info);
        }
        catch (Exception Ex)
        {
            Message = Ex.Message;
            ShowMessage(Message, MessageType.Error);
        }

    }

    protected void gvPresentDays_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

        gvPresentDays.PageIndex = e.NewPageIndex;
        BindGrid();
    }
}