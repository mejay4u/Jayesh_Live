﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;

using System.Web.UI.WebControls;

public partial class Pages_01MasterEntries_01_06_CourceDuration : System.Web.UI.Page
{
    BAL_01_06_CourceDuration BalObj = new BAL_01_06_CourceDuration();
    DAL_01_06_CourceDuration DalObj = new DAL_01_06_CourceDuration();
    string Message = string.Empty;

    public enum MessageType { Success, Error, Info, Warning };
    protected void ShowMessage(string Message, MessageType type)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), System.Guid.NewGuid().ToString(), "ShowMessage('" + Message + "','" + type + "');", true);
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindGrid();
        }

    }
    private void BindGrid()

    {
        gvCourceDuration.DataSource = DalObj.CourceDurationBind();
        gvCourceDuration.DataBind();

    }

    protected void btnAddNewCourceDuration_Click(object sender, EventArgs e)
    {


        try
        {
            BalObj.CourceDuration = txtNewCourceDuration.Text.Trim();


            DalObj.AddCourceDuration(BalObj);
            BindGrid();
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(@"<script type='text/javascript'>");
            sb.Append("$('#modal-success').modal('show');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "DeleteModalScript", sb.ToString(), false);
            ShowMessage("कोर्स कालावधी यशस्वीरित्या जोडला.", MessageType.Success);
            txtNewCourceDuration.Text = null;

        }
        catch (Exception Ex)
        {
            Message = Ex.Message;
            ShowMessage(Message, MessageType.Error);
        }

    }

    protected void gvCourceDuration_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        int index = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName.Equals("editrecord"))
        {

            GridViewRow gvrow = gvCourceDuration.Rows[index];
            hfId.Value = HttpUtility.HtmlDecode(gvrow.Cells[0].Text);

            txtCourceEdit.Text = HttpUtility.HtmlDecode(gvrow.Cells[1].Text);
            BindGrid();
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(@"<script type='text/javascript'>");
            sb.Append("$('#modal-edit').modal('show');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "EditModalScript", sb.ToString(), false);
        }


        else if (e.CommandName.Equals("deleterecord"))
        {
            GridViewRow gvrow = gvCourceDuration.Rows[index];
            string Source = null;
            Source = HttpUtility.HtmlDecode(gvrow.Cells[1].Text).Trim();
            lblDeleteBOld.Text = Source + "!<br>";
            lblDeleteMsg.Text = " आपण खरोखर हटवू इच्छिता का ? ";
            hfId.Value = gvCourceDuration.DataKeys[index].Values[0].ToString();

            BindGrid();
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(@"<script type='text/javascript'>");
            sb.Append("$('#modal-delete').modal('show');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "DeleteModalScript", sb.ToString(), false);


        }

    }

    protected void btnEditCourceDuration_Click(object sender, EventArgs e)
    {

        try
        {

            BalObj.Id = hfId.Value;
            BalObj.CourceDuration = txtCourceEdit.Text.Trim();

            DalObj.EditCourceDuration(BalObj);
            BindGrid();
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(@"<script type='text/javascript'>");

            sb.Append("$('#modal-edit').modal('hide');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "DeleteModalScript", sb.ToString(), false);
            ShowMessage("कोर्स कालावधी यशस्वीरित्या संपादित झाला.", MessageType.Success);

        }
        catch (Exception Ex)
        {
            Message = Ex.Message;
            ShowMessage(Message, MessageType.Error);
        }
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {


        try
        {
            BalObj.Id = hfId.Value;
            DalObj.DeleteCourceDuration(BalObj);
            BindGrid();

            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append(@"<script type='text/javascript'>");

            sb.Append("$('#modal-delete').modal('hide');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "DeleteModalScript", sb.ToString(), false);
            ShowMessage("कोर्स कालावधी यशस्वीरित्या काढला .", MessageType.Info);
        }
        catch (Exception Ex)
        {
            Message = Ex.Message;
            ShowMessage(Message, MessageType.Error);
        }

    }

    protected void gvCourceDuration_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

        gvCourceDuration.PageIndex = e.NewPageIndex;
        BindGrid();
    }
}