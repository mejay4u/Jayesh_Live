﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Pages_03Reports_03_02_Reports2 : System.Web.UI.Page
{
  
    DataSet Ds = new DataSet();
    string ColumnNames = string.Empty;
    string Query = string.Empty;

    string constring = ConfigurationManager.ConnectionStrings["IndrajitConString"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt = new DataTable();

    protected void Page_Load(object sender, EventArgs e)
    {
      
    }

   

    protected void btnSubmit_Click(object sender, EventArgs e)
    {


        StringBuilder sb = new StringBuilder();
        foreach (System.Web.UI.WebControls.ListItem doc in chkColumnName.Items)
        {

            if (doc.Selected)
            {
                sb.Append(doc.Value.ToString().Trim());
                sb.Append(",");
                sb.AppendFormat("");
            }
        }
        ColumnNames = sb.ToString().TrimEnd(',');
        
        Query = "SELECT " + ColumnNames + " FROM StudentInfo SI (NOLOCK) INNER JOIN [01_01_Cource] C(NOLOCK) ON(C.Id = SI.CourceName) INNER JOIN[01_02_Area] A(NOLOCK) ON(A.Id = SI.Area)  INNER JOIN[01_04_Category] CAT(NOLOCK) ON CAT.id = SI.CategoryName INNER JOIN[01_03_Cast] CS(NOLOCK) ON CS.id = SI.Cast  INNER JOIN Scheme SC(NOLOCK)ON SC.id = SI.Scheme INNER JOIN[01_01_Cource] C2(NOLOCK) ON(C2.Id = SI.CourceName2) INNER JOIN Remarks R(NOLOCK) ON( R.Id=SI.Remark) INNER JOIN PresentDays P(NOLOCK)ON(P.Id = SI.PresentDay) INNER JOIN Percentage PR(NOLOCK) ON(PR.Id = SI.Percentage) INNER JOIN CourceDuration CD(NOLOCK) ON(CD.Id = SI.CourceDuration) WHERE SI.IsDeleted=0 AND SI.StudentId IN (" + txtRollNumbers.Text + ")";


        try
        {

            string constr = ConfigurationManager.ConnectionStrings["IndrajitConString"].ConnectionString;
            SqlConnection cn = new SqlConnection(constr);
            SqlDataAdapter da = new SqlDataAdapter();




            da.SelectCommand = new SqlCommand(Query);
            da.SelectCommand.Connection = cn;
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                btnExportToExcel.Visible = true;
                gvReports2.DataSource = dt;
           
                if(chkPresenti.Checked==true)
                {
                    AddPresentiColumns();
                }
                gvReports2.DataBind();
            }
            if (dt.Rows.Count == 0)
            {
                dt.Clear();
                gvReports2.DataSource = null;
                gvReports2.DataBind();

            }

        }
        catch (Exception Ex)
        {

            string Message = Ex.Message;
        }

    }

    protected void btnExportToExcel_Click(object sender, EventArgs e)
    {

        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition", "attachment;filename=रिपोर्ट.xls");
        Response.Charset = "";
        Response.ContentType = "application/vnd.ms-excel";
        using (StringWriter sw = new StringWriter())
        {

            HtmlTextWriter hw = new HtmlTextWriter(sw);

            //To Export all pages
            //gvReports.AllowPaging = false;
            //this.BindGrid();

            gvReports2.HeaderRow.BackColor = Color.White;
            foreach (TableCell cell in gvReports2.HeaderRow.Cells)
            {
                cell.BackColor = gvReports2.HeaderStyle.BackColor;
            }
            foreach (GridViewRow row in gvReports2.Rows)
            {
                row.BackColor = Color.White;
                foreach (TableCell cell in row.Cells)
                {
                    if (row.RowIndex % 2 == 0)
                    {
                        cell.BackColor = gvReports2.AlternatingRowStyle.BackColor;
                    }
                    else
                    {
                        cell.BackColor = gvReports2.RowStyle.BackColor;
                    }
                    cell.CssClass = "textmode";
                }
            }

            gvReports2.RenderControl(hw);

            //  style to format numbers to string
            string style = @"<style> .textmode { } </style>";
            Response.Write(style);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
        }

    }






    public override void VerifyRenderingInServerForm(Control control)
    {
        /* Verifies that the control is rendered */
    }


    public void AddPresentiColumns()
    {
        dt.Columns.Add("१");
        dt.Columns.Add("२");
        dt.Columns.Add("३");
        dt.Columns.Add("४");
        dt.Columns.Add("५");
        dt.Columns.Add("६");
        dt.Columns.Add("७");
        dt.Columns.Add("८");
        dt.Columns.Add("९");
        dt.Columns.Add("१०");
        dt.Columns.Add("११");
        dt.Columns.Add("१२");
        dt.Columns.Add("१३");
        dt.Columns.Add("१४");
        dt.Columns.Add("१५");
        dt.Columns.Add("१६");
        dt.Columns.Add("१७");
        dt.Columns.Add("१८");
        dt.Columns.Add("१९");
        dt.Columns.Add("२०");
        dt.Columns.Add("२१");
        dt.Columns.Add("२२");
        dt.Columns.Add("२३");
        dt.Columns.Add("२४");
        dt.Columns.Add("२५");
        dt.Columns.Add("२६");
        dt.Columns.Add("२७");
        dt.Columns.Add("२८");
        dt.Columns.Add("२९");
        dt.Columns.Add("३०");
        dt.Columns.Add("३१");

    }


}