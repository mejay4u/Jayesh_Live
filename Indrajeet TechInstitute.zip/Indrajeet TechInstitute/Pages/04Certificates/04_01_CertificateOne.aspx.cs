﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Text;
using System.Web.SessionState;

public partial class Pages_04Certificates_04_01_CertificateOne : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnpl_Click(object sender, EventArgs e)
    {
        PlblAreaDivPrint .Text= txtArea.Text;
        PlblWardPrint.Text = txtWardNo.Text;

        PlblTrainingName.Text = txtTrainingName.Text;
        PlblWardNo5.Text = txtWardNo2.Text;
    
        PlblRemark.Text = txtRemark.Text;
        PlblTraineeCount.Text = txtTraineeCount.Text;
        lblAdminNamePrint.Text = txtBlockName.Text;

        PlblTrainingCenter.Text = txtCenterName.Text;
        PlblAreaCenterName.Text = txtCenterArea.Text;
        PlblUptoDuration.Text = txtToDate.Text;
        PlblAreaDurationDate.Text = txtFromDate.Text;
        PlblTrainingDuration.Text = txtTrainingDuration.Text;
        PlblFileNoPrint.Text = txtFileNo.Text;
        PlblAreaFilePrint.Text = txtArea2.Text;





        divnoprint.Visible = false;

        divprint.Visible = true;
       
        Session["ctrl"] = thisdivPrint;
        Control ctrl = (Control)Session["ctrl"];
        PrintHelper.PrintWebControl(ctrl);

    }
}