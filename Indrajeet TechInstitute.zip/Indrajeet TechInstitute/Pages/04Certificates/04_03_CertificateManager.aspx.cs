﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Pages_04Certificates_04_03_StudentCertificate : System.Web.UI.Page
{
    BAL_04_03_CertificateManager BalObj = new BAL_04_03_CertificateManager();
    DAL_04_03_CertificateManager DalObj = new DAL_04_03_CertificateManager();
    public enum MessageType { Success, Error, Info, Warning };
    protected void ShowMessage(string Message, MessageType type)
    {
        ScriptManager.RegisterStartupScript(this, this.GetType(), System.Guid.NewGuid().ToString(), "ShowMessage('" + Message + "','" + type + "');", true);
    }
    string constring = ConfigurationManager.ConnectionStrings["IndrajitConString"].ConnectionString;
    SqlConnection con;
    SqlCommand cmd;
    SqlDataAdapter da;
    DataTable dt = new DataTable();
    string Id = string.Empty;
    DataSet Ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            BindDDL();
        }


    }
    public void BindDDL()
    {
        Ds = DalObj.RemarkBindDDL();
        ddlRemark.DataSource = Ds.Tables[0];
        ddlRemark.DataTextField = "Remark";
        ddlRemark.DataValueField = "Id";
        ddlRemark.DataBind();

        Ds = DalObj.CourceDurationBindDDL();
        ddlCourceDuration.DataSource = Ds.Tables[0];
        ddlCourceDuration.DataTextField = "CourceDuration";
        ddlCourceDuration.DataValueField = "Id";
        ddlCourceDuration.DataBind();

        Ds = DalObj.PresentDaysBindDDL();
        ddlPresentDays.DataSource = Ds.Tables[0];
        ddlPresentDays.DataTextField = "PresentDay";
        ddlPresentDays.DataValueField = "Id";
        ddlPresentDays.DataBind();

        Ds = DalObj.PercentageBindDDL();
        ddlPercentage.DataSource = Ds.Tables[0];
        ddlPercentage.DataTextField = "Percentage";
        ddlPercentage.DataValueField = "Id";
        ddlPercentage.DataBind();


    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {

        getResults();


       
    }

    public void getResults()
    {
        string tempQuery1 = "SELECT S.Id,S.CertificateIssue,S.StudentId,CONCAT(S.StudentName, ' ', S.FatehrName, ' ', S.Surname) as StudentFullName,S.MobileNo,C.CourceName As CourceName,C2.CourceName As CourceName2 FROM StudentInfo S(NOLOCK) INNER JOIN[01_01_Cource] C(NOLOCK) ON(C.Id = S.CourceName)INNER JOIN[01_01_Cource] C2(NOLOCK) ON (C2.Id = S.CourceName2)   where  s.CourceName2 != 0 AND S.IsDeleted = 0 AND S.StudentId BETWEEN " + txtFrom.Text + " AND " + txtTO.Text + " ";
        string tempQuery2 = "SELECT S.Id,S.CertificateIssue,S.StudentId,CONCAT(S.StudentName,	' ',S.FatehrName, ' ',S.Surname) as StudentFullName,S.MobileNo,C.CourceName As CourceName,'--' As CourceName2 FROM StudentInfo S(NOLOCK) INNER JOIN[01_01_Cource] C(NOLOCK) ON(C.Id = S.CourceName)    where s.CourceName2 = 0 AND S.IsDeleted = 0 AND S.StudentId BETWEEN " + txtFrom.Text + " AND " + txtTO.Text + "";

        string MainQuery = tempQuery1 + " UNION ALL " + tempQuery2;


        try
        {

            string constr = ConfigurationManager.ConnectionStrings["IndrajitConString"].ConnectionString;
            SqlConnection cn = new SqlConnection(constr);
            SqlDataAdapter da = new SqlDataAdapter();




            da.SelectCommand = new SqlCommand(MainQuery);
            da.SelectCommand.Connection = cn;
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {

                gvStudentList.DataSource = dt;
                gvStudentList.DataBind();
            }
            if (dt.Rows.Count == 0)
            {
                dt.Clear();
                gvStudentList.DataSource = null;
                gvStudentList.DataBind();

            }

        }
        catch (Exception Ex)
        {

            string Message = Ex.Message;
        }

    }
    protected void gvStudentList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int index = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName.Equals("editrecord"))
        {
            ddlCertificateIssue.SelectedValue = "0";
            ddlCourceDuration.SelectedValue = "0";
            ddlRemark.SelectedValue = "0";
            ddlPercentage.SelectedValue = "0";
            ddlPresentDays.SelectedValue = "0";
            ddlRemark.SelectedValue = "0";
            GridViewRow gvrow = gvStudentList.Rows[index];
            Session["Id"] = gvStudentList.DataKeys[gvrow.RowIndex].Value;

            hfId.Value = HttpUtility.HtmlDecode(gvrow.Cells[0].Text);
            lblHeading.Text = HttpUtility.HtmlDecode(gvrow.Cells[2].Text);
            lblShowStudentId.Text = HttpUtility.HtmlDecode(gvrow.Cells[1].Text);
            lblShowName.Text = HttpUtility.HtmlDecode(gvrow.Cells[2].Text);
      
            lblShowMobileNo.Text = HttpUtility.HtmlDecode(gvrow.Cells[6].Text);


            //for Geting DDL Values for Perticular Record 

            Id = HttpUtility.HtmlDecode(gvrow.Cells[1].Text).Trim();

            BalObj.StudentId = Id;
            Ds = DalObj.GEtDDLValues(BalObj);
            if (Ds.Tables[0].Rows.Count > 0)
            {
                ddlCertificateIssue.SelectedValue = Ds.Tables[0].Rows[0]["CertificateIssue"].ToString();
                ddlCourceDuration.SelectedValue = Ds.Tables[0].Rows[0]["PresentDay"].ToString();
                ddlPercentage.SelectedValue = Ds.Tables[0].Rows[0]["Percentage"].ToString();
                ddlPresentDays.SelectedValue = Ds.Tables[0].Rows[0]["PresentDay"].ToString();
                ddlRemark.SelectedValue = Ds.Tables[0].Rows[0]["Remark"].ToString();
            }
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(@"<script type='text/javascript'>");
            sb.Append("$('#modal-edit').modal('show');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "EditModalScript", sb.ToString(), false);



        }



        else if (e.CommandName.Equals("ViewForm"))
        {

            GridViewRow gvrow = gvStudentList.Rows[index];



            Id = HttpUtility.HtmlDecode(gvrow.Cells[1].Text).Trim();

            BalObj.StudentId = Id;
            Ds = DalObj.StudentEditApplication(BalObj);
        
            if (Ds.Tables[0].Rows.Count > 0)
            {


                BalObj.StudentId = Id;
                string Image = DalObj.FetchImage(BalObj);
                ImageShowView.ImageUrl = Image;



              
                lblShowArea.Text = Ds.Tables[0].Rows[0]["Area"].ToString();
                lblShowCast.Text = Ds.Tables[0].Rows[0]["Cast"].ToString();
                lblShowCategory.Text = Ds.Tables[0].Rows[0]["CategoryName"].ToString();

                lblShowAddress.Text = Ds.Tables[0].Rows[0]["Address"].ToString();
                lblShowAge.Text = Ds.Tables[0].Rows[0]["Age"].ToString();
                lblShowDob.Text = Ds.Tables[0].Rows[0]["DoB"].ToString();

                lblShowEducation.Text = Ds.Tables[0].Rows[0]["Education"].ToString();

                lblShowFirstName.Text = Ds.Tables[0].Rows[0]["StudentName"].ToString();
                lblShowMiddlName.Text = Ds.Tables[0].Rows[0]["FatehrName"].ToString();
                lblShowNearMark.Text = Ds.Tables[0].Rows[0]["NearMark"].ToString();
                lblShowPhoneNo.Text = Ds.Tables[0].Rows[0]["MobileNo"].ToString();

                lblShowSurName.Text = Ds.Tables[0].Rows[0]["Surname"].ToString().Trim();

               
                lblViewCourceDuration.Text = Ds.Tables[0].Rows[0]["CourceDuration"].ToString().Trim();
                lblViewPercent.Text = Ds.Tables[0].Rows[0]["Percentage"].ToString().Trim();
                lblViewPresentDays.Text = Ds.Tables[0].Rows[0]["PresentDay"].ToString().Trim();
                lblViewRmark.Text = Ds.Tables[0].Rows[0]["Remark"].ToString().Trim();
                lblShowCertificateIssue.Text = Ds.Tables[0].Rows[0]["CertificateIssue"].ToString().Trim();


                lblTitleName.Text = lblShowFirstName.Text + " " + lblShowMiddlName.Text + " " + lblShowSurName.Text;

            }

            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append(@"<script type='text/javascript'>");
            sb.Append("$('#modal-details').modal('show');");
            sb.Append(@"</script>");
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "DeleteModalScript", sb.ToString(), false);
            Id = null;


        }

    }

    protected void btnEdit_Click(object sender, EventArgs e)
    {
        try
        {



            BalObj.StudentId = lblShowStudentId.Text.Trim();
            BalObj.CourceDuration = ddlCourceDuration.SelectedValue;
            BalObj.CertificateIssue = ddlCertificateIssue.SelectedValue;
            BalObj.Remark = ddlRemark.SelectedValue;
            BalObj.PresentDay = ddlPresentDays.SelectedValue;
            BalObj.Percentage = ddlPercentage.SelectedValue;
            string Res = DalObj.UpdateCertificateStatus(BalObj);
            if (Res == "1")
            {



                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.Append(@"<script type='text/javascript'>");

                sb.Append("$('#modal-edit').modal('hide');");
                sb.Append(@"</script>");
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "DeleteModalScript", sb.ToString(), false);
                ShowMessage("विध्यार्थी: " + lblShowName.Text + " चा अर्ज यशस्वीरित्या संपादित झाला .", MessageType.Success);
        
                getResults();

            }
            else
            {
                ShowMessage(Res + "Student updation failed", MessageType.Error);
            }
        }
        catch (Exception ex)
        {
            string Message = ex.Message;
            ShowMessage("Updation Failed, Please contact yoyr Admin", MessageType.Error);
        }

    }





    protected void gvStudentList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvStudentList.PageIndex = e.NewPageIndex;
        getResults();
    }
}