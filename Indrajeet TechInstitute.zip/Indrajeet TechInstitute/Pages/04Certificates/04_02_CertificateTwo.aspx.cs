﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Pages_04Certificates_04_02_CertificateTwo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnPrint_Click(object sender, EventArgs e)
    {
        lblAdminName.Text = txtAdminName.Text;
        lblAreaName.Text = txtArea.Text;
        lblCourceName.Text = txtCourceName.Text;
        lblFileNo.Text = txtFileNo.Text;
        lblFromDate.Text = txtFrom.Text;
        lblSign.Text = txtAdminSign.Text;
        lblStudentCount.Text = txtStudentCount.Text;
        lblToDate.Text = txtTO.Text;
        


        noprint.Visible = false;

        PrintThis.Visible = true;

        Session["ctrl"] = PrintThis;
        Control ctrl = (Control)Session["ctrl"];
        PrintHelper.PrintWebControl(ctrl);

    }
}